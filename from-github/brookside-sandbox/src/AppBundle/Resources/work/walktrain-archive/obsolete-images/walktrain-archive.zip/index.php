<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Brookside Walk + Train | Dog walking and training | Pet Sitting | Jamaica Plain, Boston</title>
<meta name="keywords" content="Dog Walking dog walkers pet sitting, sitter, Dinyee Boose, Roslindale, West Roxbury, Jamaica Plain, Boston, Ma, Massachusetts" />
<meta name="description" content="We are Jamaica Plai, MA's first dog walking service to combine dog walking and daily training reinforcements." />
<link rel="stylesheet"type="text/css" href="css/style.css" />
<link rel="shortcut icon" href="images/favicon.ico" />
<script src="js/jquery-1.4.2.min.js" type="text/javascript"></script> 
	<script src="js/cufon-yui.js" type="text/javascript"></script> 
	<script src="js/snad.js" type="text/javascript"></script> 
	<script src="js/jquery.easing.1.3.js" type="text/javascript"></script> 
	<script src="js/jquery-css-transform.js" type="text/javascript"></script> 
	<script src="js/jquery-animate-css-rotate-scale.js" type="text/javascript"></script> 
	<script src="js/fancy.js" ="text/javascript" ></script> 
	<script src="js/sliderLoop.js" type="text/javascript"></script> 
	<script src="js/myJS.js" type="text/javascript"></script> 
	
<style>
</style>
</head>

<body>
<div id="container"> 
	<div id="RepeatingFence"></div> 
    <div id="sliderBack"></div>
    <div id="FenceTop"></div>

<?php include("php/header.php");?> 
<!-- Featured content --> 
	<div id="loopedSlider"> 
    
	<div class="slider-nav">	
			<a href="#" class="previous">Prev</a> 
			<a href="#" class="next">Next</a> 
			<ul class="pagination"> 
				<li><a href="#">1</a></li> 
				<li><a href="#">2</a></li> 
				<li><a href="#">3</a></li> 
           </ul>		
		</div>
	
		<div class="container"> 
			<div class="slides"> 
            <!-- Featured slide 1 --> 
				<div class="slide slide1">
                <div class="SlideButton" style="position:absolute; z-index:25; height:auto; margin:-40px 0 0 580px"><a href="contact.php">contact us</a></div> 
					<div class="content_slide"></div> 
                    <div class="info_slide" style="margin:20px 0 0 550px">
                        <div style="position:absolute; z-index:24; width:450px; height:auto; margin:190px 0 0 -450px">
                            <p style="padding:10px; margin-left:35px; font-size:12px">This is Ruah and she is a Brookside Dog. To have your dog become a Brookside dog, too -and be just as happy- let us know. </p>
                        	</div>                  
						 
					</div> 
				</div> 
                
                <div class="slide slide2"> 
					<div class="content_slide"></div> 
					 <div class="info_slide" style="margin:20px 0 0 550px">
                        <div style="position:absolute; z-index:24; width:320px; height:auto; margin:180px 0 0 0px;">
                            <p style="padding:10px; margin-left:35px; font-size:12px">Dinyée Boose founded Brookside Walk and Train in Jamaica Plain because she knows dog walking is not just a walk in the park. It takes serious commitment, reliability and excellent dog handling skills to provide dogs with the care they deserve. </p>
                        	</div>                  
						 <div class="SlideButton"><a href="about.php">meet Dinye&egrave;</a></div>
					</div> 
				</div>
            
            <!-- Featured slide 2 --> 
            <div class="slide slide3"> 
             <div class="SlideButton" style="margin:-120px 0 0 580px; width:200px"><a href="referrals.php">see what they said</a></div>	
					<div class="info_slide">
                    <p>At Brookside, balanced dogs are happy dogs. Read some of what our balanced and happy owners said about us.</p></div> 
			  </div>
             					
		   </div>
				<!-- EndSlides --> 
		</div>


    <div id="BottomBars"> 
        <div id="HomeDesc">
        <div class="BottomButtons" style="margin-left:220px"><a href="about.php">learn more</a></div>
        	<h1>What sets us apart</h1>
            <p>We are Jamaica Plain's first dog walking service to combine dog walking and daily training reinforcements. We lead the industry by creating a higher standard of dog care through our certified walker programs.
			<br />
            <br />
Every one of our team members receives extensive training with well-respected dog trainers and must fulfill a dual-level internship program. They'll work with hundreds of dogs of all breeds and temperaments. Our walkers are taught to think like trainers -to think on their feet- to ensure the overall well-being and safety of each individual dog and the pack. 
			<br />
            <br />
Our goal is for your dog to achieve balance of the mind, body and spirit with exercise, structure and fun! As we say at Brookside Walk and Train –“a balanced dog is a happy dog.” </p>
        </div>

 	<div class="LiveryBottom">
    	<div class="BottomButtons"><a href="services.php">learn more</a></div>
    	<div class="LiveryImg"><img src="images/WalkBIG.png" width="171" height="219" alt="Brookside Walk and Train Walk Icon" /></div>
        <h2>Walk</h2>
        <p>Dogs are happiest when they are out, having a walk or a run, playing, exploring, sniffing and, at times, taking dips in a cool pool of water. We have fun taking them along for the trip.</p>
        
    </div>
    <div class="LiveryBottom">
    	<div class="BottomButtons" id="Blue"><a href="services.php#Train">learn more</a></div>
   		<div class="LiveryImg"><img src="images/TrainBIG.png" width="171" height="219" alt="Brookside Walk and Train Walk Icon" /></div>
        <h2>Walk + Train</h2>
        <p>Brookside Walk + Train's foundation is balanced dogs are happy dogs. Learn more about what that means, and see some services we offer to ensure that your little -or big- guy gets the attention they need.</p>
        </div>

    <div class="LiveryBottom">
    	<div class="BottomButtons"><a href="services.php#Play">learn more</a></div>
    	<div class="LiveryImg"><img src="images/PlayBIG.png" width="171" height="219" alt="Brookside Walk and Train Walk Icon" /></div>
        <h2>Play</h2>
        <p>Leaving town but can't take your furry buddy along? Brookside Walk + Train is happy to provide boarding services at one of our caretakers' home, or even your home. Or, send that same playful pal on an excursion with us.</p>
        </div>
</div> 
 	
</div> 
</div> 
</div>
<?php include("php/footer.php");?>
