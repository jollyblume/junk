<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Brookside Walk + Train |Jamaica Plain, Roslindale dog walkers and trainers</title>


<?php include("header.php"); ?>
<div id="SpacerTrain">
</div>

<div id="NewTrainContent" >
<div id="HomeFlash">

<table id="Table_01" width="1000" height="800" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td rowspan="2">
			<img src="Images/NewrainBackdropRaw_01.jpg" width="1" height="800" alt=""></td>
		<td>
			<img src="Images/NewrainBackdropRaw_03.jpg" width="333" height="381" alt=""></td>
        
        <td>
			<img src="Images/NewrainBackdropRaw_02.jpg" width="333" height="381" alt=""></td>
		
		<td>
			<img src="Images/NewrainBackdropRaw_04.jpg" width="333" height="381" alt=""></td>
	</tr>
	<tr>
		<td width="333" valign="top">
        <h1 class="headers">meet Jade</h1>
<p class="policiesText">Jade was Diny&eacute;e’s first training dog. When they first met,  she was a dog-aggressive puppy who would lunge, jump, and bark at other dogs. She was difficult to control and had poor communication skills. Diny&eacute;e was patient with her and, after only 2 months of training, Jade passed the basic obedience test of the American Kennel Club’s Canine Good Citizen Program (CGC). Today Jade participates in off-leash outings with other dogs. She is friendly, and often assumes the role of second in command of the pack (Diny&eacute;e being first, of course). 
and relaxes at home with our boarding visitors.</p>

<h1 class="headers">walk + train sessions</h1>
<p class="policiesText">
Our Walk and Train program's aim is to instill new basic manners in your dog, perfect those they already possess or finish up what you've started in your training. Through our Walk and Train program we work towards (helping you mold) molding a well-mannered pooch.
<br />
<br />Dogs need constant reinforcements throughout their lives - otherwise they will quickly learn to do things the easy way. also, say this if your dog does not practice manners routinely, the behaviors will never get stronger.
<br />
<br />
Even if already trained, your dog can quickly slip back into old habits or develop new habits unless desired behavior is 
reinforced. With this program, not only will we walk your dog, but also will provide reinforcement training. Your dog will benefit from both mental stimulation and physical exercise.  We will teach (or reinforce as needed) the basic obedience command. The walk can end with some off-lead free exercise or play time.
<br />
<br />Talk to us about any other special doggie requests.  We're here to help keep both you and your dog on track! You'll receive a daily write up on our training session along with exercises to work on with your pup.
<br />
<br />
</p>

<p class="policiesText">
<span class="SecondaryHead">Walk and Train Sessions:</span>
<br />Each session 30 min. 2 sessions:  $45
<br />
<br />
<b>Walk and Train Session Package 1</b>
<br />
6 sessions    $130 (one free session.)               
<br />
<br />
<b>Walk and Train Session Package 2</b>
<br />
12 sessions $270 (1 ½ free sessions)
<br />
<br />
<b>Walk and Train Session Package 3</b>
<br />
18 sessions $405 (2 free sessions)
<br />
<br />
<b>Walk and Train Session Package 4</b>
<br />
24 sessions $530 (3 free sessions)
<br />
<br />
Walk and Train Sessions should be scheduled at least twice a week. All sessions purchased in a package plan must be used within 12 weeks from the date of purchase unless a schedule is specifically discussed and set at the time of purchase. Packages must be purchased in advance.
<br />
<br />
**In conjunction with Walk & Train sessions - we recommend that periodic lessons be scheduled in order to get you caught up on your dog's new skills.
<br />
<br />
**Please keep in mind that serious behavioral issues require serious commitment and are best addressed in a teaching class or a rehabilitation program.
</p>
 </td>

        
        
        
        
        
        
        
        
        
        
        
<td width="333" valign="top">
<h1 class="headers">meet Pi</h1>
<p class="policiesText"><b>The Future Police Dog</b><br />
Pi is the latest member of the Boose family. He is Dinyee's much loved 'foster' pup, and is being trained as a police dog and a working drug dog. He began living with Dinyee and Jade in the fall of 2009 for the duration of one full year. Pi will soon team up with a K9 handler and enter the K9 Academy.
</p>
<h1 class="headers">puppy crate training</h1>
<p class="policiesText">The most important thing you can teach your puppy is how to relax and be calm.  Our foundation program is designed with this in mind.  Your new family member will not only learn to relax and be calm but also be socialized, potty trained (on cue?) crate trained and learn polite behaviors. Your puppy
will be picked up in the morning and dropped off in the afternoon between 3:00 and 4:00pm. This is a 8 week program – depending on your pooch's progress.  The Foundation program is for puppies up to 6 mths.
<br />
<br />
-575.00
<br />
<br />
**In conjunction with the Foundation Program –bi-weekly sessions are scheduled in order to get you caught up on your puppies' new skills and are included in the price of the program. 
<br />
**Puppies should have received a minimum of two sets of vaccines at least 7 days prior to the first day of the program and a first deworming. They should be kept up-to-date on vaccines throughout the program.
</p>
</td>



<td width="333" valign="top">
<h1 class="headers">meet Jessie</h1>
<p class="policiesText">Jade was Diny&eacute;e's first training dog. When they first met,  she was a dog-aggressive puppy who would lunge, jump, and bark at other dogs. She was difficult to control and had poor communication skills. Diny&eacute;e was patient with her and, after only 2 months of training, Jade passed the
basic obedience test of the American Kennel Club's Canine Good Citizen Program (CGC). Today Jade participates in off-leash outings with other dogs. She is friendly, and often assumes the role of second in command of the pack (Diny&eacute;e being first, of course). 
and relaxes at home with our boarding visitors.</p>

<h1 class="headers">dog be a dog</h1>
<p class="policiesText">Has your dog had a rough time adjusting to social situations like daycare or the dog park?  Is he nervous or timid around new dogs, or maybe even a bully? These situations are not uncommon, especially among on-the-go dog owners. Everyday at Dogwood Cottage we see the benefits of a balanced pack of dogs and specialize in welcoming new members into the group. Let us help you teach your four-legged friend how to play well with others so he can enjoy an active, social lifestyle in a pack, just as nature intended.
<br />
<br />
With the help of Lindsey Chisholm, your dog will undergo a full evaluation and have the opportunity to join the appropriate integration program. This rewarding road to stability will include structured exercise, one on one walks, on-lead pack walks, confidence boosting challenges, and eventually off leash socialization with a stable pack of dogs. Programs range from 4-8 weeks.
<br />
<br />


<b>Dogwood Cottage</b>
<br />
<br />
Let your dog be a dog again. Contact Dogwood Cottage for a consultation. Lindsey will evaluate your dog and determine how many sessions she thinks your dog will need to get fully integrated into the pack.

<br />
<br />
        price not sure yet 50-55 per day?
</td>
</tr>
</table>
</div>
</div>
<!-- End ImageReady Slices -->
<?php include ("footer.php")?>
