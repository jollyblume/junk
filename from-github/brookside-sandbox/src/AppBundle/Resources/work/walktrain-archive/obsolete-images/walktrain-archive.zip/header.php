
<link rel="stylesheet" href="css/Style.css" type="text/css" />
<link rel="shortcut icon" href="Images/bsIcon.png">
<meta name="description" content="Jamaica Plain's first dog walking service to combine dog walking with daily training reinforcements to create a balanced, happy dog."/>
<meta name="keywords" content="pet walking, dog training, puppy crate training, sitting, kitten, puppies, cat, jamaica plain, boston, dog walking" />
</head>
<body>
 
	<div id="borderTop"></div>
    <div id="container" align="center">
    	<img src="Images/lineBreakBlue.jpg" />
        <div id="header">
            <div id="logo">
                    <a href="index.php"><img src="Images/logo.jpg" border="0" alt="Brookside Walk and Train Logo"/></a>
            </div>
            <div id="MenuWords">
                       <ul>
                        <li><a href="about.php">about</a></li>
                        <li><a href="walk.php">walk</a></li>
                        <li><a href="train.php">walk+train</a></li>
                        <li><a href="play.php">play</a></li>
                        <li><a href="testimonials.php">referrals</a></li> 
                        <li><a href="contact.php">contact </a></li>
                      </ul> 
            </div>
            
    </div>
   
