
 <div id="header"> 
       <div id="logo"><a href="/"><img src="images/logo.jpg" alt="Brookside Walk and Train logo Logo" height="104" width="243" /></a></div> 
        <div id="mainNav"> 
            <ul> 
                <li><a href="about.php">about</a></li> 
                <li><a href="services.php">services</a></li> 
                <li><a href="referrals.php">referrals</a></li> 
                <li><a href="policies.php">policies</a></li>
                <li><a href="contact.php">contact</a></li> 
            </ul> 
        </div>    
    </div> 

<div style="clear:both"></div> 

<div id="content">