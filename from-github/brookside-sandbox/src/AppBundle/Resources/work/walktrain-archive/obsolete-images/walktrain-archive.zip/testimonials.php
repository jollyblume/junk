<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Brookside Walk + Train | Testimonials</title>

<?php include("header.php"); ?>

<div id="Spacer"></div>
<div id="TestimonialContent" align="center"> 
<div id="ParagraphsFoPolicies">
<table width="1000"
><tr>
<td width="333" valign="top">
<h1 class="headers">Jessie</h1>
<p class="PokeyText"><span class="Pokey"></span>Dinyée has been walking Jessie almost every week day at noon for the past 5 years.  Jessie waits for Dinyée to arrive at the house like she waits for me and my husband to get home from work: with excitement, anticipation, and sheer joy when she arrives.  "Jessie loves Dinyée," I tell anyone who asks about how Jessie likes her dog walker. My husband and I adopted Jessie, a black lab/Rottweiler mix, from a shelter in Louisiana in May 2005.  She was approximately 9 months old at the time, and had some significant behavioral issues.  Dinyée readily joined in our efforts to provide our troubled dog with consistency, discipline, boundaries, and loads of affection.  The strides Jessie has taken over the years are remarkable.  For example, she went from chomping on a visitor's arm one year, to lying blissfully with her head in the visitor's lap two years later.  "What a lovely dog," is a frequent comment friends and family, and we definitely have Dinyée to thank for being so attentive to Jessie's needs and anxieties.
Thank you, Diny&eacute;e! 
<br />
<br />
-Martha Badger</p>

<h1 class="headers">Duke</h1>
<span class="Pokey6"></span>
<p class="policiesText">My dog is a handful. Or maybe I should say two handfuls. A great big hound mix from the shelter - 100lbs of bouncing baby boy. Little did I know that he would love to chase small animals and was big enough to drag me around on the other end of the leash while doing so. Dinyée  has walked him for several years now. There is no one that I could imagine trusting my dog with more. He's so well behaved for her, and I get the benefit of essentially having him receive training and exercise every day, making him so much better behaved for me as well. He's always a calmer, and happier dog when she takes him out. I'm so lucky to have her help me with my dog!
<br />
<br />
-Ellen A.
</p>  
</td>


<td width="333" valign="middle">
<h1 class="headers">Pokey</h1>
<span class="Pokey3"></span>
<p class="policiesText">Dinyée was great at getting to know our dog's personality and understanding her behaviors.  Dinyée  continually gives us concrete and easy ways to work with Pokey (our dog), and as a result, Pokey is much more confident and calm all-around! 
<br />
<br />
-Susan Roe
<br />
<br />
<br />
<br />




<h1 class="headers">Ned</h1>
<p class="policiesText">
<span class="Pokey4"></span>
Ned is our sweet, goofy, 80 plus pound Old English Sheepdog who just turned five.  He is fiercely protective and stubborn but he has the gentlest soul once you get to know him.  Getting to know him is key though.  Ned adores those he knows; but he can be mistrustful of others, for instance the mailman, the woman around the corner, anyone wearing a hat etc.  But when Dinyee first started working with Ned over three years ago, it was as if an instant connection was formed. Ned trusts her, is well behaved (most of the time) for her, and respects her.  Quite simply, he adores her ~ just mention her name, and he wiggles and jiggles with excitement! Nothing makes me happier than knowing that Ned is safe, happy and well cared for when I cannot be with him.  And when Ned is with Dinyee, he is all of those things.

Her love of the dogs is obvious, but she also has a true understanding of what they need in terms of leadership and consistency, exercise and "play", and firmness and fairness.  The combination of these things is what makes her so special.  I have learned so much from her work with Ned, and appreciate all that she does for Ned, and for my peace of mind!
<br />
<br />
-Liss Murphy
</p>
<h1 class="headers">Venus</h1>
<p class="policiesText">
<span class="Pokey7"></span>
I love having Diny&egrave;e walk Venus. Not only is it a relief knowing that Venus gets out during the day to exercise, I also have seen major improvements in her behaviour since being with Diny&egrave;e 2x a week. Venus is much calmer around other dogs, and her listening skills have improved. I know Diny&egrave;e's consistent application of training principals makes all the difference!  Venus is a pitbull and loves to play hard. Now with Diny&egrave;e she has found a better balance between structured play and out of control play. She is happier and so are all the other dogs and people in the parks.  :-)
<br />
<br />
-Jennifer Walsh

</p>
</td>

<td width="333" valign="top">
<h1 class="headers">Sammy</h1>
<p class="policiesText">
<span class="Pokey1"></span>
Our ridgeback, Sammy, participates in the off leash group walks and loves every minute of it!  It has been such a huge relief to know that she is in such capable hands while we are at work.  Diny&eacute;e truly understands Sammy and sees the spunky, goofy dog that she is in spite of her insecurities.  Diny&eacute;e has worked very hard to raise Sammy's confidence and comfort level and as a result, Sammy is a more balanced, happier dog.  As owners, we can relax knowing that she is well cared for and happy while we are gone!  What more can you want?
<br />
<br />
-Laura Morgon
</p>
<h1 class="headers">Mindy</h1>
<p class="policiesText">
<span class="Pokey5"></span>
After having cycled through a few less than enthusiastic dog walkers, we feel very lucky to have found Diny&eacute;e. She truly seems to enjoy being with the dogs, cares deeply for their well-being and is very interested in reinforcing and extending their training. She has been taking our dog Mindy for extended off-leash walks for several years and Mindy is always very eager and happy to follow her on their daily excursions. Dinyée has put in a lot of work to educate herself about dog behavior and this allows her charges to benefit from all the positive aspects of being out and about in a pack while allowing us to never have to worry for Mindy's safety - Diny&eacute;e is definitely the leader of the pack!  
<br />
<br />
-Amna Saeed-Kothe</p>
</td>


</tr>
</table>
</div>
</div>

<?php include("footer.php");?>
