<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>contact</title>
<meta name="keywords" content="Dog Walking dog walkers pet sitting, sitter, Dinyee Boose, Roslindale, West Roxbury, Jamaica Plain, Boston, Ma, Massachusetts" />
<meta name="description" content="We are Jamaica Plai, MA's first dog walking service to combine dog walking and daily training reinforcements." />
<link rel="stylesheet"type="text/css" href="css/style.css" />
<link rel="shortcut icon" href="images/favicon.ico" />
<style>
#ThreeColumns{height:810px}
.headers{font-size:18px}
</style>

</head>

<body>
<div id="container"> 
	<div id="RepeatingFence"></div>
    <div id="InsideHeader"></div> 
    <div style="position:absolute; z-index:-1; width:873px; height:655px; top:360px">
    <table id="Table_01" width="873" height="655" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td><img src="images/rua_01.png" width="175" height="131" alt=""></td>
		<td><img src="images/rua_02.png" width="174" height="131" alt=""></td>
		<td><img src="images/rua_03.png" width="175" height="131" alt=""></td>
		<td><img src="images/rua_04.png" width="174" height="131" alt=""></td>
		<td><img src="images/rua_05.png" width="175" height="131" alt=""></td>
	</tr><tr>
		<td><img src="images/rua_06.png" width="175" height="131" alt=""></td>
		<td><img src="images/rua_07.png" width="174" height="131" alt=""></td>
		<td><img src="images/rua_08.png" width="175" height="131" alt=""></td>
		<td><img src="images/rua_09.png" width="174" height="131" alt=""></td>
		<td><img src="images/rua_10.png" width="175" height="131" alt=""></td>
	</tr><tr>
		<td><img src="images/rua_11.png" width="175" height="131" alt=""></td>
		<td><img src="images/rua_12.png" width="174" height="131" alt=""></td>
		<td><img src="images/rua_13.png" width="175" height="131" alt=""></td>
		<td><img src="images/rua_14.png" width="174" height="131" alt=""></td>
		<td><img src="images/rua_15.png" width="175" height="131" alt=""></td>
	</tr><tr>
		<td><img src="images/rua_16.png" width="175" height="131" alt=""></td>
		<td><img src="images/rua_17.png" width="174" height="131" alt=""></td>
		<td><img src="images/rua_18.png" width="175" height="131" alt=""></td>
		<td><img src="images/rua_19.png" width="174" height="131" alt=""></td>
		<td><img src="images/rua_20.png" width="175" height="131" alt=""></td>
	</tr>
	<tr>
		<td><img src="images/rua_21.png" width="175" height="131" alt=""></td>
		<td><img src="images/rua_22.png" width="174" height="131" alt=""></td>
		<td><img src="images/rua_23.png" width="175" height="131" alt=""></td>
		<td><img src="images/rua_24.png" width="174" height="131" alt=""></td>
		<td><img src="images/rua_25.png" width="175" height="131" alt=""></td>
	</tr>
</table>
    
    
    
    
    </div>
<?php include("php/header.php");?> 		
		
		<div id="ThreeColumns">
        	<div id="col1">
             <h1>contact us</h1> 
                <p class="policiesText">Business hours for booking service
                <br /> 
                <br /> 
                Monday - Friday 8:30am to 6:00pm<br /> 
                Saturday - 8:30am to 1:00pm<br /> 
                Sunday – CLOSED<br /> 
                <br /> 
                Phone: 617 285 2419<br /> 
                Email: <a class="footerTextReverse" href="mailto:info@brooksidewalkandtrain.com" target="_blank">info@brooksidewalkandtrain.com</a> 
                </p> 
            </div>
            
            
            <div id="col2">
            <h1 class="blank">&nbsp;</h1> 
<p class="policiesText">**Please note that these are only the business hours for booking service. </p> 
        <p class="policiesText">We are available for walks/pet sits 7 days a week from morning until 8:00pm.
          Please fill in the form or contact us by phone to inquire further about our services. </p> 
            </div>

        <div id="col3">
           <table width="300" align="right"> 
            <form method="POST" action="contactForm.php"> 
            <tr> 
            <td></td> 
            <td><span class="SecondaryHead" align="right"> become a client</span></td> 
            </tr> 
            
            <tr> 
            <td></td> 
            <td class="imputText"><label>required fields (*)</label></td> 
            </tr> 
        
            <tr> 
            <td class="imputText"><label>first name*</label></td> 
            <td><input type="text" name="FirstName"><br></td> 
            </tr> 
            
            <tr> 
            <td class="imputText"><label>last name*</label></td> 
            <td><input type="text" name="LastName"></td> 
            </tr> 
        
            <tr> 
            <td class="imputText"><label>street address</label></td> 
            <td><input type="text" name="streetaddress"></td> 
            </tr> 
             
            <tr> 
            <td class="imputText"><label>city*</label></td> 
            <td><input type="text" name="City"></td> 
            </tr> 
        
            <tr> 
            <td class="imputText"><label>state</label></td> 
            <td><input type="text" name="State"></td> 
            </tr> 
        
            <tr> 
            <td class="imputText"><label>zip</label></td> 
            <td><input type="text" name="zip"></td> 
            </tr> 
            
            <tr> 
            <td class="imputText"><label>email*</label></td> 
            <td><input type="text" name="email"></td> 
            </tr> 
        
            <tr> 
            <td class="imputText"><label>phone</label></td> 
            <td><input type="text" name="phone"></td> 
            </tr> 
            
            <tr> 
            <td></td> 
            <td class="imputText">dog information</td> 
            </tr> 
            
            <tr> 
            <td class="imputText"><label>dogname*</label></td> 
            <td><input type="text" name="dogname"></td> 
            </tr> 
            
            <tr> 
            <td class="imputText"><label>gender</label></td> 
            <td><input type="text" name="gender"></td> 
            </tr> 
        
            <tr> 
            <td class="imputText"><label>microchipnumber</label></td> 
            <td><input type="text" name="microchipnumber"></td> 
            </tr> 
        
            <tr> 
 
            <td></td> 
            <td class="imputText"><label>emergency contact info</label></td> 
            </tr> 
        
            <tr> 
            <td class="imputText"><label>contact name</label></td> 
            <td><input type="text" name="contactname"></td> 
            </tr> 
            
            <tr> 
            <td class="imputText"><label>phonenumber</label></td> 
            <td><input type="text" name="phonenumber"></td> 
            </tr> 
        
            <tr> 
            <td class="imputText"><label>cellphonenumber</label></td> 
            <td><input type="text" name="cellphonenumber"></td> 
            </tr> 
            
            <tr> 
            <td></td> 
            <td class="imputText"><label>Veterinary Information</label></td> 
            </tr> 
          
            <tr> 
            <td class="imputText"><label>Vet hospital Name</label></td> 
            <td><input type="text" id="emergency cell phone" style="width:100%" /></td> 
            </tr> 
            
            <tr> 
            <td class="imputText"><label>vet phone Number</label></td> 
            <td><input type="text" id="emergency cell phone" style="width:100%" /></td> 
            </tr> 
            
            <tr> 
            <td class="imputText"><label>city</label></td> 
            <td><input type="text" id="emergency cell phone" style="width:100%" /></td> 
            </tr> 
        
            <tr> 
            <td></td> 
            <td align="right"><input type="submit" name="submit" value="Submit"></td> 
            </form> 
            </tr> 
        </table>

            </div>
        </div>
</div> 
</div> 
</div>
<?php include("php/footer.php");?>