<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>services</title>
<meta name="keywords" content="Dog Walking dog walkers Dinyee Boose, Jamaica Plain, Boston, Ma, Massachusetts" />
<meta name="description" content="Brookside Walk and Train in Jamaica Plain offers unparalleled walking and training services." />
<link rel="stylesheet"type="text/css" href="http://brooksidewalkandtrain.com/css/style.css" />
<link rel="shortcut icon" href="images/favicon.ico" />
<style>
    h3{border:none; margin-bottom:0px}
    h1{font-size:24px}
	#ThreeColumns{
            
            clear:both;
            height:auto;
            margin-top: 169px !important;
          }
     .full {
         margin:0 auto;
         width:100%;
         max-width:980px;
         display:block;
         clear:both;
         position:relative           
     }
     .spacer {
       margin:0 auto;
         width:100%;
      height:100px;
         display:block;
         clear:both;
         position:relative                    
     }
	#container{height:auto}
</style>

 </head>
<body>
<div id="container"> 
<div class="FixedGoing">
	<a href="#scrollToHere" class="scrollPage"><img src="images/Scroll_Walk.png" />walk</a><br />
    <a href="#Train" class="scrollPage"><img src="images/Scrol_Train.png" />train</a><br />
     <a href="#Play" class="scrollPage"><img src="images/Scroll_Play.png" />play</a>
    </div>
	<div style="position:absolute; z-index:-1; top:480px; width:942px; margin-left:100px;height:639px">
    </div>
	<div id="RepeatingFence"></div> 
    <div id="InsideHeader"></div>
<?php include("php/header.php");?> 		
		<div id="ThreeColumns" class="Orange" style="height:auto">
        	<div class="WalkHead" style="position:absolute; top:115px; margin-left:860px; z-index:-1; width:95px; height:49px"><img src="images/WT_WalkHead.png" width="95" height="49" /></div>
        	<div style="position:absolute; top:475px; margin-left:400px; z-index:-1; width:508px; height:328px; ">
            <table id="Table_01" width="508" height="328" border="0" cellpadding="0" cellspacing="0">
       		<tr><td><img src="images/Dinyee_01.png" width="127" height="82" alt=""></td>
            <td><img src="images/Dinyee_02.png" width="127" height="82" alt=""></td>
            <td><img src="images/Dinyee_03.png" width="127" height="82" alt=""></td>
            <td><img src="images/Dinyee_04.png" width="127" height="82" alt=""></td>
        </tr><tr><td><img src="images/Dinyee_05.png" width="127" height="82" alt=""></td>
            <td><img src="images/Dinyee_06.png" width="127" height="82" alt=""></td>
            <td><img src="images/Dinyee_07.png" width="127" height="82" alt=""></td>
            <td><img src="images/Dinyee_08.png" width="127" height="82" alt=""></td>
        </tr><tr><td><img src="images/Dinyee_09.png" width="127" height="82" alt=""></td>
            <td><img src="images/Dinyee_10.png" width="127" height="82" alt=""></td>
            <td><img src="images/Dinyee_11.png" width="127" height="82" alt=""></td>
            <td><img src="images/Dinyee_12.png" width="127" height="82" alt=""></td>
        </tr><tr><td><img src="images/Dinyee_13.png" width="127" height="82" alt=""></td>
            <td><img src="images/Dinyee_14.png" width="127" height="82" alt=""></td>
            <td><img src="images/Dinyee_15.png" width="127" height="82" alt=""></td>
            <td><img src="images/Dinyee_16.png" width="127" height="82" alt=""></td>
        </tr></table>
    </div>
            
    	<div id="col1">
            <h1>where don't we go?</h1>
            <p>We like to take the dogs to safe, open green space,and we know all the little, peaceful places. All around the Emerald Necklace, Franklin Park and even parts of the cemetery. There are also some private, wooded areas in Roslindale and West Roxbury that we like, too. And, of course, the urban walk is good. But we don't go to the Arboretum and we don't go to dog parks.</p> 
<p>On our walks with your dog, we would be happy to reinforce any training you are working on with your dog. Just let us know.</p>

<h5>on-leash group walks </h5>
<p>Groups comprise of no more than 3 dogs.</p>
<p><b>30min</b> $17<br> 
<b>additional dog</b> $8</p>

<p><b>40min</b> 20<br>  
<b>additional dog</b> $10 </p>

<p><b>60min</b> $24<br>
<b>additional dog</b> $10</p>

<h5>weekend walks </h5>
<p>Planning a day trip? Work weekends? No worries. We offer weekend walks. </p>
<p><b>20 minutes</b> $25<br>
<b>additional dog</b> $10</p>
 
            </div>
            
            
            <div id="col2">
            <h1 class="blank">&nbsp;</h1>
            <h5>individual walks</h5>
			<p>Our individual dog walks are perfect for the pet who needs "their own space.” During these one-on-one excursions, our staff’s undivided attention is devoted to your pooch.</p> 
<p><b>20 minutes</b> $22 <br />
<b>40 minutes</b>  $27<br/> 
<b>additional dog</b> $10</p>


            </div>


            <div id="col3">
            <h1 class="blank">&nbsp;</h1>
           <!-- <h5>off-leash field trips </h5>
<p>With up to 6 dogs per pack, and under the supervision of an energetic and experienced handler, these outings allow your dog to explore our natural world while socializing with other dogs. All dogs are pre-screened for social skills, responsiveness and compatibility to ensure they are a good fit for our off leash program. </p>
<p><b>1 hour -$24</b></p>
<p>Add $10.00 per additional dog per household</p>-->
<!--<h5>puppy visits </h5>
<p>For your new addition to the family, we offer 2-3 visits a day depending upon your needs. </p>
<p><b>$12.00 per visit</b> - Includes feeding, walking and playtime. <br />
***Also beneficial for a senior dog that may need extra outside time. </p>-->
<h5>morning and evening visits</h5>
<p style="width:200px">Can't make it home in time for the evening feeding and a walk around the neighborhood? We offer 20 minute after business hours walks from 4-8pm. Morning visits are between the hours of 7-9am.</p> 
<p><b>20 minutes</b> $25<br/>
<b>additional dog</b> $10</p>
<p>Pee breaks are designed for the new addition to your family and also, for senior dogs that may need extra time outside.</p>
<p><b>Pee Breaks</b> $15 <br />
<b>additional dog</b> $8</p>
</div>

</div>
 
<!--<div class="full">
	<div id="col1">
            <h5>meet jade</h5>
            <p><span style="float:right; width:124px; height:155px; padding:5px"><img src="images/WT_Jade.png" height="155" width="124" /></span>When Dinyee first met Jade  she was an energetic and rambunctious puppy who’d lunge, jump, and bark at other dogs. She was difficult to control and had poor communication skills. Dinyée was patient with her and, after only 2 months of training, Jade passed the basic obedience test of the American Kennel Club's Canine Good Citizen Program (CGC). Today Jade participates in off-leash outings with other dogs. She is friendly, and often assumes the role of second in command of the pack (Dinyée being first, of course). and relaxes at home with our boarding visitors.</p>
            </div>
            
            
            <div id="col2">
            <h5>meet pi</h5>
            <p><span style="float:right; width:162px; height:175px; margin-top:30px; padding:5px 5px 15px 5px"><img src="images/WT_Pi.png" height="175" width="162" /></span><b>The Future Police Dog</b><br />Pi is the latest member of the Boose family. He is Dinyee's much loved 'foster' pup, and is being trained as a police dog and a working drug dog. He began living with Dinyée and Jade in the fall of 2009 for the duration of one full year. Pi will soon team up with a K9 handler and enter the K9 Academy.</p>
            </div>


            <div id="col3">
            <h5>meet jessie</h5>
            <p><span style="float:right; width:105px; height:122px; padding:5px"><img src="images/WT_Jessie.png" height="122" width="105" /></span>When Dinyée started walking Jessie 5 years ago, she was anxious and fearful around other dogs. As their relationship developed, Jessie began to trust Dinyée, allowing her to be introduced with other dogs. As Jessie became more comfortable and confident walking and playing with others in her yard, Dinyée began to take her on field trips with other dogs. Today Jessie is part of the pack, is off leash, social with other doggies and having fun being a dog. She is so calm now that Dinyée will find her in the back of the van, napping with the others. Kudos to Jessie!</p>
            </div>

</div>-->


<div class="spacer"></div>



<div id="ThreeColumns" class="Blue">
<div id="Train"></div>
			<div class="WalkHead" style="position:absolute; margin:-53px 0 0 780px; z-index:-1; width:169px; height:49px"><img src="images/WT_TrainHead.png" width="169" height="49" /></div>
        
            <div class="spacer"></div>
            <div style="clear:both"></div>
          <div id="TwoColumns">
           <div class="full">  
          <!--<p>Dogs crave routine and need constant reinforcement throughout their lives. Otherwise they quickly learn to do things the easy way. Even if they have already been trained your dog can devolve into their old habits, unless desired behavior is reinforced.</p> 
<p>Our walk and train programs develop new, positive habits as we build upon -or alter- the old. We not only walk your dog, but we also provide reinforcement training. Your dog will benefit from both mental stimulation and physical exercise and develop the routine they crave, making them a happier and more balanced as a result.</p>
-->
<p style="font-size:3em; font-weight:bold; color:#27aae1; text-align:center; padding:20px">
<!--<h2>Board and Train -- 2 3 and  4 week programs.</h2>

<p>Coming Soon</p>

<h2>Structure Day Care</h2>

<p>Coming Soon</p>

<h2>Puppy Foundation Program</h2> 

<p>Coming Soon</p>

<h2>Day School</h2> 

<p>Coming Soon</p>

<h2>Group Training</h2> 

<p>Coming Soon</p>

<h2>Private In Home Training</h2> 

<p>Coming Soon</p>-->
 
<h1>Services coming soon!</h1> 
<p>Call for more info and to set up an evaluation today!</p>
<h5>Board and Train -- 2 3 and 4 week programs</h5>
<h5>Structure Day Care</h5>
<h5>Puppy Foundation Program</h5>
<h5>Day School</h5>
<h5>Group Training</h5> 
<h5>Private In Home Training</h5> 
<h5>Walk + Trains</h5>
 
 
</div>          
 <!-- <div class="TwoLeft">
                <h1>walk + train sessions</h1>
              <h5>walk + train Sessions: </h5>
<p>Each session 30 min. 2 sessions: $45 </p>
<div id="WTSessions">
<li><p><b>Package One</b>
<br />6 sessions $130<br /><br />   </p></li>
<li><p><b>Package Two</b><br />
12 sessions $270 <br /><br /> </p></li>
 <div style="clear:both"></div>
<li><p><b>Package Three</b><br />
18 sessions $405<br /><br /> 
  </p></li>
<li><p><b>Package Four</b><br />
24 sessions $530<br /><br /> </p></li>
</div>
<div style="width:100%; height:45px"></div> 
<p>Walk and Train Sessions should be scheduled at least twice a week. All sessions purchased in a package plan must be used within 12 weeks from the date of purchase unless a schedule is specifically discussed and set at the time of purchase. Packages must be purchased in advance.</p> 
<p class="smallPrint">**In conjunction with Walk & Train sessions - we recommend that periodic lessons be scheduled in order to get you caught up on your dog's new skills. </p>
<p class="smallPrint">**Please keep in mind that serious behavioral issues require serious commitment and are best addressed in a teaching class or a rehabilitation program.
</p>
                </div>-->
 <!--<div class="TwoRight">
                <h1>puppy crate training</h1>
                <p> The most important thing you can teach your puppy is how to relax and be calm. Your new family member will not only learn to relax and be calm, but also be socialized, potty trained, crate trained and learn polite behaviors. We pick up your puppy in the morning and drop them off in the afternoon between 3:00 and 4:00pm. This 8 week program is ideal for puppies up to 6 months old.</p> 
<p><b>Puppy Crate Training - $625.00 </b></p>
<p><br /><br />**In conjunction with the Foundation Program –bi-weekly sessions are scheduled in order to get you caught up on your puppies' new skills and are included in the price of the program.</p> 
<p>**Puppies should have received a minimum of two sets of vaccines at least 7 days prior to the first day of the program and a first de-worming. They should be kept up-to-date on vaccines throughout the program.
                <h1>pack integration</h1>
                <p><b>let your dog be a dog</b></p>
<p>Is your dog nervous or timid around new dogs, or maybe even a bully? These situations are not uncommon, especially among on-the-go dog owners. </p>
<p>Each day at Brookside Walk and Train, the benefits of working individual dogs into a pack become obvious. Your dog will undergo a full evaluation and have the opportunity to join the appropriate integration program. This rewarding road to stability will include structured exercise, one-on-one walks, on-lead pack walks, confidence boosting challenges, and eventually off leash socialization with a stable pack of dogs. </p>
<p>Let us help you teach your four-legged friend how to play well with others so he can enjoy an active, social lifestyle in a pack, just as nature intended. </p>
<p>Programs range from 4-8 weeks. </p>
<p><b>Pack Integration - $50 per day</b></p>
                </div>-->
            </div> 
</div>
      <div style="clear:both"></div>


<div id="ThreeColumns" class="Pink">
			<div id="Play"></div>
			<div class="WalkHead" style="position:absolute; margin:-53px 0 0 850px; z-index:-1; width:101px; height:49px"><img src="images/WT_PlayHead.png" width="101" height="49" /></div>
        	<div id="col1">
            <h1>play + excursions</h1>
            <p><b>a stay means play</b></p> 
<p>Dogs need to walk, run, play, explore, sniff, and at times dip in a cool pool of water. To ensure nice play, our experienced handlers monitor energy levels for the safety of each individual dog and maintain a good pack dynamic. </p>
<p>We are happy to reinforce any training you are working on, just let us know! </p>

<!--<h5>off-leash field trips </h5>
<p>With up to 6 dogs per pack, and under the supervision of an energetic and experienced handler, these outings allow your dog to explore our natural world while socializing with other dogs. All dogs are pre-screened for social skills, responsiveness and compatibility to ensure they are a good fit for our off leash program. </p>
<p><b>1 hour -$24</b></p>
<p>Add $10.00 per additional dog per household</p>-->

<h5>boarding </h5>
<p>Leaving town but can’t take your furry buddy along? Brookside Walk and Train is happy to provide boarding services at one of our caretakers’ home, or even your home. Our caretakers will adhere to your pet’s routines, and provide any specific accommodations it may require. Feel free to contact us with any questions. </p>
<!--<h5>Your home boarding </h5>
<p>Boarding takes place at one of our caretakers’ home. We will maintain feeding and care routines. Your dog must be well-mannered with people and other dogs. When your dog boards with us for a week, he’ll spend his days working in the field with his pet sitter-enjoying the great outdoors! </p>
<p><b>$70 per day</b></p>-->
 
            </div>
            
            
            <div id="col2" style="width:635px">
            <h1 class="blank">&nbsp;</h1>
            <div id="FlabellComponent" align="right"></div>
            <div style="margin-top:40px">
                <div id="col2">
                   <h5>your home overnights</h5>
                    <p>We are happy to stay at your place with your dog. We provide this service for all clients looking to keep their pooch in their own environment, but especially find this option beneficial for our senior and less socially-oriented clients. Our overnight care typically begins in the early evening with a walk, feeding and slumbering with your pup and then a morning walk and feeding.</p>
<p><b>$60-per day</b></p>
                    <img style="margin-top:55px" src="images/Serivces_Kitty.png" width="301" height="125" />
                </div>
                    
                <div id="col2" style="width:280px">
                   <h5>pet sitting</h5> 
                        <p>This service includes in-home visits – morning, mid-day, and evening. Each visit may last 30 minutes. </p>
                        <p>With week-long pet sitting, your dog will have a fun time, meeting up with a buddy for play date or just a fun car ride while doing errands-anything to keep him company while you’re away! </p>
                        <p><b>$70 per day </b></p>
                        <p>Add $25 per additional dog per household for our boarding services.</p>
				  <h5>cat care </h5>
                        <p>We come to your house for one or two visits per day to play, feed and scoop. </p>
                        <p><b>$18 per visit </b></p>
                        <p>add $5.00 per household with more than 2 kitties.</p>
		     </div>
     </div>
</div>
</div> 
</div> 
</div>
<script type="text/javascript" src="http://jqueryjs.googlecode.com/files/jquery-1.3.2.min.js"></script> 
<script type="text/javascript"> 
$(document).ready(function() {
$('.scrollPage').click(function() {
   var elementClicked = $(this).attr("href");
   var destination = $(elementClicked).offset().top;
   $("html:not(:animated),body:not(:animated)").animate({ scrollTop: destination-20}, 800 );
   return false;
});
});
</script> 
<script src="js/swfobject.js" type="text/javascript"></script> 
<script type="text/javascript"> 
  		// JAVASCRIPT VARS
			// cache buster
			var cacheBuster = "?t=" + Date.parse(new Date());		
			// stage dimensions
			var stageW = 655;//"100%";
			var stageH = 350;//"100%";
			// ATTRIBUTES
		    var attributes = {};
		    attributes.id = 'FlabellComponent';
		    attributes.name = attributes.id;
			// PARAMS
			var params = {};
			params.bgcolor = "#ffffff";
		    /* FLASH VARS */
			var flashvars = {};				
			/// if commented / delete these lines, the component will take the stage dimensions defined 
			/// above in "JAVASCRIPT SECTIONS" section or those defined in the settings xml			
			flashvars.componentWidth = stageW;
			flashvars.componentHeight = stageH;
			/// path to the content folder(where the xml files, images or video are nested)
			/// if you want to use absolute paths(like "http://domain.com/images/....") then leave it empty("")
			flashvars.pathToFiles = "banner/";
			flashvars.xmlPath = "xml/banner.xml";
			/** EMBED THE SWF**/
			swfobject.embedSWF("preview.swf"+cacheBuster, attributes.id, stageW, stageH, "9", "js/expressInstall.swf", flashvars, params);
		</script>
          <div class="spacer"></div>
<?php include("php/footer.php");?>