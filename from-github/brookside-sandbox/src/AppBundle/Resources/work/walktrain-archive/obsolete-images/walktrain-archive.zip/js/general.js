jQuery(document).ready(function($) {

	function fixYellow() {
	    if (navigator.userAgent.toLowerCase().indexOf('chrome') > -1) {
	        $id = 'user-login-form';
	        $.each($("#"+$id+" :input[type=text], #"+$id+" :input[type=password]"), 
	function(i, j) {
	            t = $('#'+j.id);
	            t.clone().appendTo(t.parent());
	            t.remove();
	        });
	    }
	}
	window.setTimeout(fixYellow, 100);

	
	/* IMPORTANT! This site uses a great deal of z-indexing.
	 * The following jQuery reverses the z-index stacking order of elements on the page.
	 * This will ensure the elements higher in the HTML will also have a higher z-index order,
	 * solving most of the IE stacking issues.
	 */
	$(function() {
		var zIndexNumber = 1000;
		$('body.front #content-bottom div').each(function() {
			$(this).css('zIndex', zIndexNumber);
			zIndexNumber -= 10;
		});
	});
	
	// Keep Menu Active When Hovering over child UL
	$('#nice-menu-1 li ul').hover(function(){
	  $(this).parent('li').addClass('hover-down');
	  }, function() {
	  $(this).parent('li').removeClass('hover-down');
	});
  	
  	// Create Rotating Promos using jQuery Cycle Plugin
  	//$('#block-views-rotating_promo-block_1 .view-content ul').after('<div class="promo-wrapper"><div id="prev"><img src="/sites/all/themes/lbds/i/prev.jpg" /></div><div id="next"><img src="/sites/all/themes/lbds/i/next.jpg" /></div><div id="controls"><div id="nav"></div><div id="control"><span id="play" class="control">Play</span><span id="pause" class="control">Pause</span></div></div></div>').cycle({
  	$('#block-views-rotating_promo-block_1 .view-content ul').after('<div class="promo-wrapper-top"></div><div class="promo-wrapper-left"><div id="prev"><img src="/sites/all/themes/lbds/i/prev.jpg" /></div></div><div class="promo-wrapper-right"><div id="next"><img src="/sites/all/themes/lbds/i/next.jpg" /></div></div><div class="promo-wrapper-bottom"><div id="controls"><div id="nav"></div><div id="control"><span id="play" class="control">Play</span><span id="pause" class="control">Pause</span></div></div></div>').cycle({
		fx: 'fade',
		timeout: 8000,
		speed: 800,
		prev: '#prev',
		next: '#next',
		pager: '#controls #nav'
	});
	
	// Rotating Promos | Pause & Resume Buttons
	$('#pause').click(function() { 
    	$('#block-views-rotating_promo-block_1 .view-content ul').cycle('pause'); 
	});
	
	$('#play').click(function() { 
    	$('#block-views-rotating_promo-block_1 .view-content ul').cycle('resume'); 
	});
	$('#nav a').click(function(){
		$('#block-views-rotating_promo-block_1 .view-content ul').cycle('pause');
		$('#play').removeClass('active');
		$('#pause').addClass('active');
	});
	
	// Play & Pause Active Classes
	$('#play').addClass('active');
	$('span.control').click(function() {
		//$('#block-views-home_rotator-block_1 .view-content ul').cycle(this.id);
		$('span.control').removeClass('active');
		$(this).addClass('active');
	});
	
	// Add the LBDS Author Badge to 'Meet our Founder' homepage block
	$('#block-block-4 .inner').append('<div id="author-lbds"><img src="/sites/all/themes/lbds/i/author-lbds.png" /></div>');
	
	// Make the 'How can I...' blocks slide
	$('#block-views-how_can_i-block_1 ul li.views-row').hover(function(){
	  $(".cover", this).stop().animate({top:'158px'},{queue:false,duration:300});
	}, function() {
	  $(".cover", this).stop().animate({top:'0px'},{queue:false,duration:300});
	});
	
	// Center the DropDown Menus under the primary nav links
	var contentDivWidth;
    var calculatedWidth;
	var calculatedY;
	
	$('.nice-menu-down > li').each(function() {
	  var contentDivWidth = parseInt($(this).css('width'));
	  var calculatedWidth = contentDivWidth - 203 + "px";
	  var calculatedY = ( parseInt(calculatedWidth) / 2 ) + "px";
	  		
	  $(this).children('ul').css('left', calculatedY);
  	});
	
	//$('#user-login-form input#edit-name').defaultText({defText: 'Username'});
	//$('#user-login-form input#edit-pass').defaultText({defText: 'Password'});
	
	// Fix 5px Margin on Secondary Navigation Hovers
	$('#sidebar-first .inner ul.menu li').hover(function(){
		$(this).children('a').addClass('tiny-gap');
	}, function() {
		$(this).children('a').removeClass('tiny-gap');
	});
	$('#sidebar-first .inner ul.menu li.active').hover(function(){
		$(this).children('a').removeClass('tiny-gap');
	});
	$('#sidebar-first .inner ul.menu li.active-trail').hover(function(){
		$(this).children('a').removeClass('tiny-gap');
	});
  
});
