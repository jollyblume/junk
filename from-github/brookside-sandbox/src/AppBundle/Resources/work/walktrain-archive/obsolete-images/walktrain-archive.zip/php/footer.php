<div id="footer"> 
	<div id="footerInside">
    	<div style="position:absolute; margin:185px 0 0 800px"><p>site design<a href="http://www.thatstheanthem.com" target="_blank">anthem sobo</a></div> 
    	<ul> 
        	<li class="ZapatosIs">
            <h4>© Brookside Walk + Train</h4>
			<p>Serving Jamaica Plain, Roslindale, and West Roxbury. 
            <br />
             <br />
			 p:617 285 2419<br />
			 e:<a href="mailto:info@brooksidewalkandtrain.com">info@brooksidewalkandtrain.com</a></p></li>
        
        
             <li class="ZapatosIs"> 
        	 <h4>employment opportunities </h4> 
            <p>To inquire about employment opportunities, please email us your experience and a copy of your resume.</p> 
        </li> 
        <li class="ZapatosIs"> 
        	<h4>site map</h4> 
            <div style="display:inline; float:left; width:100px">
                <p><a href="index.php"> home</a><br /> 
                   <a href="about.php"> about</a><br /> 
                   <a href="services.php"> services</a></p>
                   </div>
              <div style="display:inline; float:left; width:100px">
                   <p><a href="referrals.php"> referrals</a><br /> 
                   <a href="policies.php"> policies</a><br>
                   <a href="contact.php"> contact</a>
                    </p> 
             <div style="position:absolute; margin:-85px 0 0 95px"><a href="http://www.thumbtack.com/ma/boston/dog-walking/#sort=popularity&hilite=JuCsyS0Mug1H4g" target="_blank"><img src="../images/Thumbtack.png" width="46" height="74" /></a></div>
             </div>
        </li> 
        <li class="ZapatosIs" style="width:150px"> 
        	<h4>social</h4>  
        	<p><a href="http://www.facebook.com/pages/brookside-walk-train/126026570771055?ref=ts" target="_blank">
            	<span class="SocialIcon" style="background-image:url(images/facebookLogo.jpg)"></span>Facebook</a><br /> 
            	<a href="apps.facebook.com/dogbook/profile/view/9284340" target="_blank"><span class="SocialIcon" style="background-image:url(images/twitterLogo.jpg)"></span>Dogbook</a><br /> 
                <a href="http://www.yelp.com/biz/brookside-walk-train-jamaica-plain" target="_blank"><span class="SocialIcon" style="background-image:url(images/yelpLogo.jpg)"></span>Yelp!</a><br /> 
                </p></li> 
        </ul> 
    </div> 
    <div class="Copywrite"></div>
</div>
<script type="text/javascript"> 
 
var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-7889737-14']);
_gaq.push(['_trackPageview']);
 
(function() {
var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();
 
</script>
</body> 
</html>