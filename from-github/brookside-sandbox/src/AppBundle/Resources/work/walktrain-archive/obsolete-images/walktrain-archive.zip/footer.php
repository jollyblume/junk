
<div id="footer" align="center">
<div id="footerInfo">
<table>
<tr>
<td id="AddressFooter" valign="top" width="200">
<span class="typicalTextFooterUnder">
&copy; Brookside Walk + Train</span>
		<br />
<span class="typicalTextFooterText">Serving Jamaica Plain, Roslindale, and West Roxbury.
<br />
<br />
p:617 285 2419<br />
e:info@brooksidewalkandtrain.com</span>
</td>

<td valign="Top" width="230">
<span class="typicalTextFooterUnder">Employment Opportunities</span>
<br />
<span class="typicalTextFooterText">
To inquire about employment opportunities, please email us your experience and a copy of your resume.</span>
<p class="contactForEmployment"><a class="footerText" href="mailto:info@brooksidewalkandtrain.com" target="_blank">CONTACT</a></p>
</td>

<td valign="top" width="30">&nbsp;
</td>

<td valign="top" width="70">
<span class="typicalTextFooterUnder">Site Map</span>
<a class="footerText" href="index.php">home</a><br />
<a class="footerText" href="about.php">about</a><br />
<a class="footerText" href="walk.php">walk</a><br />
</td>

<td valign="top" width="70">
<span class="typicalTextFooterNoUnder">&nbsp;&nbsp;</span><br />
<a class="footerText" href="train.php">walk+train</a><br />
<a class="footerText" href="testimonials.php">referrals</a><br />
<a class="footerText" href="play.php">play</a><br />
</td>

<td valign="top" width="70">
<span class="typicalTextFooterNoUnder">&nbsp;&nbsp;</span><br />
<a class="footerText" href="policies.php">policies</a> <br />
<a class="footerText" href="contact.php">contact</a><br />
</td> 

<td valign="top" width="10" >
<span class="typicalTextFooterNoUnder">&nbsp;&nbsp;</span><br />
</td>

<td width="260" align="right" valign="middle">
<a href="http://apps.facebook.com/dogbook/profile/view/9284340?ref=nf" target="_blank"><img src="Images/footerIcons_01.png" border="0" alt="DogBook Logo" title="Dogbook!"/></a>
<a href="http://www.facebook.com/pages/Jamaica-Plain-MA/brookside-walk-train/126026570771055?ref=ts&__a=14" target="_blank"><img src="Images/footerIcons_02.png" border="0" alt="Facebook Logo" title="Fan us on Facebook"/></a>
<a href="http://www.yelp.com/biz/brookside-walk-train-jamaica-plain" target="_blank"><img src="Images/footerIcons_03.png" border="0" alt="Yelp Logo" title="Rate Us On Yelp"/></a>

<br />
<br />
<a class="SiteCredit" href="http://www.thatstheanthem.com"><img src="Images/siteCredit.png" alt="Anthem Sobo" border="0" /></a>                  
</td>
</tr>
<table>

<td width="360" valign="top">
</td>
</tr>                    
</table>
</div>
</div>
<div id="bottomBottom"></div>

<script type="text/javascript">

var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-7889737-14']);
_gaq.push(['_trackPageview']);

(function() {
var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();

</script>




