<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"> 
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>contact</title>
<meta name="keywords" content="Dog Walking dog walkers pet sitting, sitter, Dinyee Boose, Roslindale, West Roxbury, Jamaica Plain, Boston, Ma, Massachusetts" />
<meta name="description" content="We are Jamaica Plai, MA's first dog walking service to combine dog walking and daily training reinforcements." />

<style>
#ThreeColumns{height:810px}
.headers{font-size:18px}
</style>
<link type="text/css" rel="stylesheet" href="../resources/css/validform.css?10" /> 
       <link rel="stylesheet" href="../resources/css/jquery.ui.css" type="text/css" media="screen" charset="utf-8"/> 
        
        
		<script type="text/javascript" src="../resources/libraries/jquery.js"></script> 
        <script src="../resources/js/jquery-ui-1.7.1.custom.min.js" type="text/javascript" charset="utf-8"></script> 
        <script type="text/javascript" src="../resources/libraries/validform.js?89"></script> 
        <script type="text/javascript" src="../resources/libraries/ajaxfileupload.js"></script> 
        <script type="text/javascript" src="../resources/libraries/jquery.livequery.min.js"></script> 
        <script src="../resources/libraries/jquery.alphanumeric.js" type="text/javascript" charset="utf-8"></script> 
        <link rel="stylesheet" href="css/style.css" />
    </head> 
    
    
<body>
<div id="container"> 
	<div id="RepeatingFence"></div>
    <div id="InsideHeader"></div> 
    <div style="position:absolute; z-index:-1; width:873px; height:655px; top:360px">
    <table id="RuaPhoto" width="873" height="655" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td><img src="images/rua_01.png" width="175" height="131" alt=""></td>
		<td><img src="images/rua_02.png" width="174" height="131" alt=""></td>
		<td><img src="images/rua_03.png" width="175" height="131" alt=""></td>
		<td><img src="images/rua_04.png" width="174" height="131" alt=""></td>
		<td><img src="images/rua_05.png" width="175" height="131" alt=""></td>
	</tr><tr>
		<td><img src="images/rua_06.png" width="175" height="131" alt=""></td>
		<td><img src="images/rua_07.png" width="174" height="131" alt=""></td>
		<td><img src="images/rua_08.png" width="175" height="131" alt=""></td>
		<td><img src="images/rua_09.png" width="174" height="131" alt=""></td>
		<td><img src="images/rua_10.png" width="175" height="131" alt=""></td>
	</tr><tr>
		<td><img src="images/rua_11.png" width="175" height="131" alt=""></td>
		<td><img src="images/rua_12.png" width="174" height="131" alt=""></td>
		<td><img src="images/rua_13.png" width="175" height="131" alt=""></td>
		<td><img src="images/rua_14.png" width="174" height="131" alt=""></td>
		<td><img src="images/rua_15.png" width="175" height="131" alt=""></td>
	</tr><tr>
		<td><img src="images/rua_16.png" width="175" height="131" alt=""></td>
		<td><img src="images/rua_17.png" width="174" height="131" alt=""></td>
		<td><img src="images/rua_18.png" width="175" height="131" alt=""></td>
		<td><img src="images/rua_19.png" width="174" height="131" alt=""></td>
		<td><img src="images/rua_20.png" width="175" height="131" alt=""></td>
	</tr>
	<tr>
		<td><img src="images/rua_21.png" width="175" height="131" alt=""></td>
		<td><img src="images/rua_22.png" width="174" height="131" alt=""></td>
		<td><img src="images/rua_23.png" width="175" height="131" alt=""></td>
		<td><img src="images/rua_24.png" width="174" height="131" alt=""></td>
		<td><img src="images/rua_25.png" width="175" height="131" alt=""></td>
	</tr>
</table>
</div>
<?php include("php/header.php");?> 		
		
		<div id="ThreeColumns">
        	<div id="col1">
             <h1>contact us</h1> 
                <p class="policiesText">Business hours for booking service
                <br /> 
                <br /> 
                Monday - Friday 8:30am to 6:00pm<br /> 
                Saturday - 8:30am to 1:00pm<br /> 
                Sunday – CLOSED<br /> 
                <br /> 
                Phone: 617 285 2419<br /> 
                Email: <a class="footerTextReverse" href="mailto:info@brooksidewalkandtrain.com" target="_blank">info@brooksidewalkandtrain.com</a> 
                </p> 
            </div>
            
            
            <div id="col2">
            <h1 class="blank">&nbsp;</h1> 
<p class="policiesText">**Please note that these are only the business hours for booking service. </p> 
        <p class="policiesText">We are available for walks/pet sits 7 days a week from morning until 8:00pm.
          Please fill in the form or contact us by phone to inquire further about our services. </p> 
            </div>

        <div id="col3">
        <script type="text/javascript"> 
            function validateCaptcha()
            {
                challengeField = $("input#recaptcha_challenge_field").val();
                responseField = $("input#recaptcha_response_field").val();
                var html = $.ajax({
                type: "POST",
                url: "ajax.recaptcha.php",
                data: "recaptcha_challenge_field=" + challengeField + "&recaptcha_response_field=" + responseField,
                async: false
                }).responseText;
                if (html.replace(/^\s+|\s+$/, '') == "success")
                {
                    $("#captchaStatus").html(" ");
                    // Uncomment the following line in your application
                    return true;
                }
                else
                {
                    $("#captchaStatus").html("Your captcha is incorrect. Please try again");
                    Recaptcha.reload();
                    return false;
                }
            }
            function fileuploads()
            {
                return true;
                b = true;
                $('.toupload').each(function() {
                if($(this).prev().val()) {
                if(!ajaxFileUpload($(this).prev().attr('id'))) {b=false};
                $(this).attr('sel','file_specified');
                } else {
                $(this).attr('sel','');
                $(this).attr('rel','');
            }
            });
            return true;
        }
        function sim_ajaxFileUpload(id)
        {
            //starting setting some animation when the ajax starts and completes
            $('#'+id+'_upload').attr('rel','loading_file');
            $('input[type=submit]').attr('disabled','true');
            $('input[type=submit]').css('color','#999999');
            $('[name=validating_space]').addClass('uploading_file');
            var that= this;
            setTimeout(function(){ 
            $('#'+id+'_upload').html('<img style="vertical-align:middle" src="../resources/images/icons/accept.png" />  '+' This is a preview, 0 bytes uploaded'); 
            $('#'+id+'_upload').attr('rel','');
            $('#'+id+'_upload').attr('hel','uploaded');
            $('[name=validating_space]').removeClass('uploading_file');
            $('input[type=submit]').attr('disabled','');
            $('input[type=submit]').css('color','#000000');
            $('.toupload').each(function() {
            if ($(this).attr('rel') && $(this).attr('rel')!='no_upload') {
            $('[name=validating_space]').addClass('uploading_file');
            $('input[type=submit]').attr('disabled','true');
            $('input[type=submit]').css('color','#999999');
        }
        });
        }, 2000);
    }  
    function ajaxFileUpload(id)
    {
        //starting setting some animation when the ajax starts and completes
        $('#'+id+'_upload').attr('rel','loading_file');
        $('input[type=submit]').attr('disabled','true');
        $('input[type=submit]').css('color','#999999');
        $('[name=validating_space]').addClass('uploading_file');
        /*
        prepareing ajax file upload
        url: the url of script file handling the uploaded files
        fileElementId: the file type of input element id and it will be the index of  $_FILES Array()
        dataType: it support json, xml
        secureuri:use secure protocol
        success: call back function when the ajax complete
        error: callback function when the ajax failed
        */
        $.ajaxFileUpload(
        {
            url:'doajaxfileupload.php?id='+id,
            secureuri:false,
            fileElementId:id,
            dataType: 'json',
            success: function (data, status)
            {
                if(typeof(data.error) != 'undefined')
                {
                    if(data.error != '')
                    {
                        $('#'+id+'_upload').html('<img style="vertical-align:middle" src="../resources/images/icons/error.png" />  '+data.error); 
                        $('#'+id+'_upload').attr('rel','');
                        $('#'+id+'_upload').attr('hel','');
                        $('[name=validating_space]').removeClass('uploading_file');
                        $('input[type=submit]').attr('disabled','');
                        $('input[type=submit]').css('color','#000000');
                        $('.toupload').each(function() {
                        if ($(this).attr('rel') && $(this).attr('rel')!='no_upload') {
                        $('[name=validating_space]').addClass('uploading_file');
                        $('input[type=submit]').attr('disabled','true');
                        $('input[type=submit]').css('color','#999999');
                    }
                    });
                    return false;
                    }else
                    {
                        $('#'+id+'_upload').html('<img style="vertical-align:middle" src="../resources/images/icons/accept.png" />  '+data.msg); 
                        oFormObject = document.forms[0];
                        oFormObject.elements[id+'_name'].value = data.msg; 
                        $('#'+id+'_upload').attr('rel','');
                        $('#'+id+'_upload').attr('hel','uploaded');
                        $('[name=validating_space]').removeClass('uploading_file');
                        $('input[type=submit]').attr('disabled','');
                        $('input[type=submit]').css('color','#000000');
                        $('.toupload').each(function() {
                        if ($(this).attr('rel') && $(this).attr('rel')!='no_upload') {
                        $('[name=validating_space]').addClass('uploading_file');
                        $('input[type=submit]').attr('disabled','true');
                        $('input[type=submit]').css('color','#999999');
                    }
                    });
                    return true;
                }
            }
            },
            error: function (data, status, e)
            {
                alert(e);
            }
        }
        )
        return false;
    }  
    function upload_event(id)
    {
        $('#'+id).each(function() {
        if($(this).val()) {
        ajaxFileUpload($(this).attr('id'));
        $(this).next().attr('sel','file_specified');
        } else {
        $(this).next().attr('sel','');
        $(this).next().attr('rel','');
    }    
    });
}    
$(document).ready(function() {
$('.field_block').each(function(){
var w = 500;
var wl = $(this).children(':first-child').find('.fieldlabel_block:first').width();
$(this).children(':first-child').find('.fielddesc_block:first').width(w-wl-30-30);
}
);
$('#recaptcha_logo').remove();
$('#recaptcha_tagline').remove();
$('input[type=file_old]').live('change',function() {
if($(this).val()) {
ajaxFileUpload($(this).attr('id'));
$(this).next().attr('sel','file_specified');
} else {
$(this).next().attr('sel','');
$(this).next().attr('rel','');
}
});
$.datepicker.setDefaults($.datepicker.regional['en']);
$('.datepicker').datepicker({ dateFormat: 'dd MM yy', duration: 'fast', changeMonth:true, changeYear:true, gotoCurrent:true, showOtherMonths:true ,yearRange: '1920:2020' });
$('.datepicker').disablekeyboard();
//$('.inside').inFieldLabels({fadeDuration:10});
});
// <![CDATA[
$(function(){
var objForm = new ValidForm("htmlform", "One or more errors occurred. Check the marked fields and try again.");
objForm.addElement('element_4d3b2e8b4a4d5', 
'first name',
'',
true, 
9000,
null,
'',
'Enter only letters, numbers and punctuation symbols.',
'we need to know what to call you.', 
'The value is the hint value. Enter your own value.', 
'Your input is too short. A minimum of  characters or digits are allowed.', 
'Your input is too long. A maximum of  characters or digits are allowed.');
objForm.addElement('element_4d3b2ed83f116', 
'last name',
'',
true, 
9000,
null,
'',
'Enter only letters, numbers and punctuation symbols.',
'please enter your last name', 
'The value is the hint value. Enter your own value.', 
'Your input is too short. A minimum of  characters or digits are allowed.', 
'Your input is too long. A maximum of  characters or digits are allowed.');
objForm.addElement('element_4d3b2ee98d23c', 
'street address',
'',
true, 
9000,
null,
'',
'Enter only letters, numbers and punctuation symbols.',
'please enter a valid address', 
'The value is the hint value. Enter your own value.', 
'Your input is too short. A minimum of  characters or digits are allowed.', 
'Your input is too long. A maximum of  characters or digits are allowed.');
objForm.addElement('element_4d3b2f3dd3a2b', 
'city',
'',
true, 
9000,
null,
'',
'Enter only letters, numbers and punctuation symbols.',
'where do you live?', 
'The value is the hint value. Enter your own value.', 
'Your input is too short. A minimum of  characters or digits are allowed.', 
'Your input is too long. A maximum of  characters or digits are allowed.');
objForm.addElement('element_4d3b2f5d4bb2c', 
'state',
'',
true, 
9000,
null,
'',
'Enter only letters, numbers and punctuation symbols.',
'This field is required.', 
'The value is the hint value. Enter your own value.', 
'Your input is too short. A minimum of  characters or digits are allowed.', 
'Your input is too long. A maximum of  characters or digits are allowed.');
objForm.addElement('element_4d3b2f6c1c3f5', 
'zip code',
'',
false, 
9000,
null,
'',
'Enter only letters, numbers and punctuation symbols.',
'This field is required.', 
'The value is the hint value. Enter your own value.', 
'Your input is too short. A minimum of  characters or digits are allowed.', 
'Your input is too long. A maximum of  characters or digits are allowed.');
objForm.addElement('element_4d3b2f7b85604', 
'email',
'',
true, 
9000,
null,
'',
'Enter only letters, numbers and punctuation symbols.',
'please enter a valid email address', 
'The value is the hint value. Enter your own value.', 
'Your input is too short. A minimum of  characters or digits are allowed.', 
'Your input is too long. A maximum of  characters or digits are allowed.');
objForm.addElement('element_4d3b2f9f31a95', 
'phone',
'',
true, 
9000,
null,
'',
'Enter only letters, numbers and punctuation symbols.',
'please enter a phone number', 
'The value is the hint value. Enter your own value.', 
'Your input is too short. A minimum of  characters or digits are allowed.', 
'Your input is too long. A maximum of  characters or digits are allowed.');
objForm.addElement('element_4d3b2ff817005', 
'dog name',
'',
true, 
9000,
null,
'',
'Enter only letters, numbers and punctuation symbols.',
'This field is required.', 
'The value is the hint value. Enter your own value.', 
'Your input is too short. A minimum of  characters or digits are allowed.', 
'Your input is too long. A maximum of  characters or digits are allowed.');
objForm.addElement('element_4d3b300bdf530', 
'dog gender',
'',
false, 
9000,
null,
'',
'Enter only letters, numbers and punctuation symbols.',
'This field is required.', 
'The value is the hint value. Enter your own value.', 
'Your input is too short. A minimum of  characters or digits are allowed.', 
'Your input is too long. A maximum of  characters or digits are allowed.');
objForm.addElement('element_4d3b301aef5a1', 
'microchip number',
'',
false, 
9000,
null,
'',
'Enter only letters, numbers and punctuation symbols.',
'This field is required.', 
'The value is the hint value. Enter your own value.', 
'Your input is too short. A minimum of  characters or digits are allowed.', 
'Your input is too long. A maximum of  characters or digits are allowed.');
objForm.addElement('element_4d3b304fc29bd', 
'contact name',
'',
true, 
9000,
null,
'',
'Enter only letters, numbers and punctuation symbols.',
'please tell us who to contact', 
'The value is the hint value. Enter your own value.', 
'Your input is too short. A minimum of  characters or digits are allowed.', 
'Your input is too long. A maximum of  characters or digits are allowed.');
objForm.addElement('element_4d3b306f6c7cf', 
'contact number',
'',
true, 
9000,
null,
'',
'Enter only letters, numbers and punctuation symbols.',
'we need to know how to contact you', 
'The value is the hint value. Enter your own value.', 
'Your input is too short. A minimum of  characters or digits are allowed.', 
'Your input is too long. A maximum of  characters or digits are allowed.');
objForm.addElement('element_4d3b30874e91f', 
'cell phone number',
'',
true, 
9000,
null,
'',
'Enter only letters, numbers and punctuation symbols.',
'it\'s in case of emergency', 
'The value is the hint value. Enter your own value.', 
'Your input is too short. A minimum of  characters or digits are allowed.', 
'Your input is too long. A maximum of  characters or digits are allowed.');
objForm.addElement('element_4d3b30aa39ddd', 
'vet hospital',
'',
false, 
9000,
null,
'',
'Enter only letters, numbers and punctuation symbols.',
'This field is required.', 
'The value is the hint value. Enter your own value.', 
'Your input is too short. A minimum of  characters or digits are allowed.', 
'Your input is too long. A maximum of  characters or digits are allowed.');
objForm.addElement('element_4d3b30be62841', 
'vet phone number',
'',
false, 
9000,
null,
'',
'Enter only letters, numbers and punctuation symbols.',
'This field is required.', 
'The value is the hint value. Enter your own value.', 
'Your input is too short. A minimum of  characters or digits are allowed.', 
'Your input is too long. A maximum of  characters or digits are allowed.');
objForm.addElement('element_4d3b30edf094b', 
'vet city',
'',
false, 
9000,
null,
'',
'Enter only letters, numbers and punctuation symbols.',
'This field is required.', 
'The value is the hint value. Enter your own value.', 
'Your input is too short. A minimum of  characters or digits are allowed.', 
'Your input is too long. A maximum of  characters or digits are allowed.');
});
// ]]></script> 
<script type="text/javascript"> 
var RecaptchaOptions = {
theme : 'clean',"width":400
};</script> 

<form id="htmlform" method="get" enctype="multipart/form-data" action="js/form_processor.php" class="validform" onSubmit="return (fileuploads());"> 
<fieldset class="main_fieldset"> 
<div class="formname"> 
<h1>contact us</h1> 
</div> 
<div class="vf__description"> 
<p> 
</p> 
</div> 
<div class="vf__notice"> 
<p>Required fields are printed in bold.</p> 
</div> 
<div class="formbody"> 
<ol> 
    <li> 
        <div class='field_block'> 
            <div class="vf__required"> 
                <div class="fieldlabel_block" style="width:85px;"> 
                    <label  sel="" tooltip="" for='element_4d3b2e8b4a4d5'> 
                        first name<span class="asterisk_required">*</span> 
                    </label> 

                </div> 
                <div class="fielddesc_block"> 
                    <textarea name="element_4d3b2e8b4a4d5" cols="15" rows="1" label="first name" id="element_4d3b2e8b4a4d5" value="" class="vf__text" ></textarea> 
                </div> 
            </div> 
        </div> 
    </li> 
    <li > 
        <div class='field_block'> 
            <div class="vf__required"> 
                <div class="fieldlabel_block" style="width:85px;"> 
                    <label  sel="" tooltip="" for='element_4d3b2ed83f116'> 
                        last name<span class="asterisk_required">*</span> 
                    </label> 
                </div> 
                <div class="fielddesc_block"> 
                    <textarea name="element_4d3b2ed83f116" cols="15" rows="1" label="last name" id="element_4d3b2ed83f116" value="" class="vf__text" ></textarea> 
                </div> 
            </div> 
        </div> 
    </li> 
    <li > 
        <div class='field_block'> 
            <div class="vf__required"> 
                <div class="fieldlabel_block" style="width:85px;"> 
                    <label  sel="" tooltip="" for='element_4d3b2ee98d23c'> 
                        street address<span class="asterisk_required">*</span> 
                    </label> 
                </div> 
                <div class="fielddesc_block"> 
                    <textarea name="element_4d3b2ee98d23c" cols="15" rows="1" label="street address" id="element_4d3b2ee98d23c" value="" class="vf__text" ></textarea> 
                </div> 
            </div> 
        </div> 
    </li> 
    <li > 
        <div class='field_block'> 
            <div class="vf__required"> 
                <div class="fieldlabel_block" style="width:85px;"> 
                    <label  sel="" tooltip="" for='element_4d3b2f3dd3a2b'> 
                        city<span class="asterisk_required">*</span> 
                    </label> 
                </div> 
                <div class="fielddesc_block"> 
                    <textarea name="element_4d3b2f3dd3a2b" cols="15" rows="1" label="city" id="element_4d3b2f3dd3a2b" value="" class="vf__text" ></textarea> 
                </div> 
            </div> 
        </div> 
    </li> 
    <li > 
        <div class='field_block'> 
            <div class="vf__required"> 
                <div class="fieldlabel_block" style="width:85px;"> 
                    <label  sel="" tooltip="" for='element_4d3b2f5d4bb2c'> 
                        state<span class="asterisk_required">*</span> 
                    </label> 
                </div> 
                <div class="fielddesc_block"> 
                    <textarea name="element_4d3b2f5d4bb2c" cols="15" rows="1" label="state" id="element_4d3b2f5d4bb2c" value="" class="vf__text" ></textarea> 
                </div> 
            </div> 
        </div> 
    </li> 
    <li > 
        <div class='field_block'> 
            <div class="vf__optional"> 
                <div class="fieldlabel_block" style="width:85px;"> 
                    <label  sel="" tooltip="" for='element_4d3b2f6c1c3f5'> 
                    zip code</label> 
                </div> 
                <div class="fielddesc_block"> 
                    <textarea name="element_4d3b2f6c1c3f5" cols="15" rows="1" label="zip code" id="element_4d3b2f6c1c3f5" value="" class="vf__text" ></textarea> 
                </div> 
            </div> 
        </div> 
    </li> 
    <li > 
        <div class='field_block'> 
            <div class="vf__required"> 
                <div class="fieldlabel_block" style="width:85px;"> 
                    <label  sel="" tooltip="" for='element_4d3b2f7b85604'> 
                        email<span class="asterisk_required">*</span> 
                    </label> 
                </div> 
                <div class="fielddesc_block"> 
                    <textarea name="element_4d3b2f7b85604" cols="15" rows="1" label="email" id="element_4d3b2f7b85604" value="" class="vf__text" ></textarea> 
                </div> 
            </div> 
        </div> 
    </li> 
    <li > 
        <div class='field_block'> 
            <div class="vf__required"> 
                <div class="fieldlabel_block" style="width:85px;"> 
                    <label  sel="" tooltip="" for='element_4d3b2f9f31a95'> 
                        phone<span class="asterisk_required">*</span> 
                    </label> 
                </div> 
                <div class="fielddesc_block"> 
                    <textarea name="element_4d3b2f9f31a95" cols="15" rows="1" label="phone" id="element_4d3b2f9f31a95" value="" class="vf__text" ></textarea> 
                </div> 
            </div> 
        </div> 
    </li> 
    <li > 
        <div class='field_block'> 
            <div class="vf__required"> 
                <div class="fieldlabel_block" style="width:85px;"> 
                    <label  sel="" tooltip="" for='element_4d3b2ff817005'> 
                        dog name<span class="asterisk_required">*</span> 
                    </label> 
                </div> 
                <div class="fielddesc_block"> 
                    <textarea name="element_4d3b2ff817005" cols="15" rows="1" label="dog name" id="element_4d3b2ff817005" value="" class="vf__text" ></textarea> 
                </div> 
            </div> 
        </div> 
    </li> 
    <li > 
        <div class='field_block'> 
            <div class="vf__optional"> 
                <div class="fieldlabel_block" style="width:85px;"> 
                    <label  sel="" tooltip="" for='element_4d3b300bdf530'> 
                    dog gender</label> 
                </div> 
                <div class="fielddesc_block"> 
                    <textarea name="element_4d3b300bdf530" cols="15" rows="1" label="dog gender" id="element_4d3b300bdf530" value="" class="vf__text" ></textarea> 
                </div> 
            </div> 
        </div> 
    </li> 
    <li > 
        <div class='field_block'> 
            <div class="vf__optional"> 
                <div class="fieldlabel_block" style="width:85px;"> 
                    <label  sel="" tooltip="" for='element_4d3b301aef5a1'> 
                    microchip number</label> 
                </div> 
                <div class="fielddesc_block"> 
                    <textarea name="element_4d3b301aef5a1" cols="15" rows="1" label="microchip number" id="element_4d3b301aef5a1" value="" class="vf__text" ></textarea> 
                </div> 
            </div> 
        </div> 
    </li> 
    <li > 
        <div class='field_block'> 
            <div class="vf__required"> 
                <div class="fieldlabel_block" style="width:85px;"> 
                    <label  sel="" tooltip="" for='element_4d3b304fc29bd'> 
                        contact name<span class="asterisk_required">*</span> 
                    </label> 
                </div> 
                <div class="fielddesc_block"> 
                    <textarea name="element_4d3b304fc29bd" cols="15" rows="1" label="contact name" id="element_4d3b304fc29bd" value="" class="vf__text" ></textarea> 
                </div> 
            </div> 
        </div> 
    </li> 
    <li > 
        <div class='field_block'> 
            <div class="vf__required"> 
                <div class="fieldlabel_block" style="width:85px;"> 
                    <label  sel="" tooltip="" for='element_4d3b306f6c7cf'> 
                        contact number<span class="asterisk_required">*</span> 
                    </label> 
                </div> 
                <div class="fielddesc_block"> 
                    <textarea name="element_4d3b306f6c7cf" cols="15" rows="1" label="contact number" id="element_4d3b306f6c7cf" value="" class="vf__text" ></textarea> 
                </div> 
            </div> 
        </div> 
    </li> 
    <li > 
        <div class='field_block'> 
            <div class="vf__required"> 
                <div class="fieldlabel_block" style="width:85px;"> 
                    <label  sel="" tooltip="" for='element_4d3b30874e91f'> 
                        cell phone number<span class="asterisk_required">*</span> 
                    </label> 
                </div> 
                <div class="fielddesc_block"> 
                    <textarea name="element_4d3b30874e91f" cols="15" rows="1" label="cell phone number" id="element_4d3b30874e91f" value="" class="vf__text" ></textarea> 
                </div> 
            </div> 
        </div> 
    </li> 
    <li > 
        <div class='field_block'> 
            <div class="vf__optional"> 
                <div class="fieldlabel_block" style="width:85px;"> 
                    <label  sel="" tooltip="" for='element_4d3b30aa39ddd'> 
                    vet hospital</label> 
                </div> 
                <div class="fielddesc_block"> 
                    <textarea name="element_4d3b30aa39ddd" cols="15" rows="1" label="vet hospital" id="element_4d3b30aa39ddd" value="" class="vf__text" ></textarea> 
                </div> 
            </div> 
        </div> 
    </li> 
    <li > 
        <div class='field_block'> 
            <div class="vf__optional"> 
                <div class="fieldlabel_block" style="width:85px;"> 
                    <label  sel="" tooltip="" for='element_4d3b30be62841'> 
                    vet phone number</label> 
                </div> 
                <div class="fielddesc_block"> 
                    <textarea name="element_4d3b30be62841" cols="15" rows="1" label="vet phone number" id="element_4d3b30be62841" value="" class="vf__text" ></textarea> 
                </div> 
            </div> 
        </div> 
    </li> 
    <li > 
        <div class='field_block'> 
            <div class="vf__optional"> 
                <div class="fieldlabel_block" style="width:85px;"> 
                    <label  sel="" tooltip="" for='element_4d3b30edf094b'> 
                    vet city</label> 
                </div> 
                <div class="fielddesc_block"> 
                    <textarea name="element_4d3b30edf094b" cols="15" rows="1" label="vet city" id="element_4d3b30edf094b" value="" class="vf__text" ></textarea> 
                </div> 
            </div> 
        </div> 
    </li> 
    <li > 
        <div class="fieldcontrol_block"> 
            <div class="vf__navigation"> 
                <input type="hidden" name="vf__dispatch" value="htmlform" /> 
                <input type="hidden" name="disableresizing" value="0" /> 
                <input type="submit" name="element_4d3b3132e6af2" value="submit" class="vf__button"  /> 
            </div> 
        </div> 
    </li> 
</ol> 
</div> 

</fieldset> 
</form> 
<br /> 
<div id ="rsv_space" class="rsv_space"> 
</div> 
<div  class="validating_space" name="validating_space"> 
<script type="text/javascript"> 
function resizeParentIframe() {
try{
parent.document.getElementById('myiframe').style.height = document.body.clientHeight+'px';
parent.document.getElementById('myiframe').style.width = document.body.clientWidth+'px';
}
catch(error) {}
}
// Create the tooltips only on document loading
$(document).ready(function() 
{
resizeParentIframe();
// Notice the use of the each() method to acquire access to each elements attributes
$('label[tooltip]').livequery(function()
{
if ($(this).attr('tooltip')) {
$(this).qtip({
content: $(this).attr('tooltip'), // Use the tooltip attribute of the element for the content
style: 'light' // Give it a crea mstyle to make it stand out
});
}
});
});</script> 
<script type="text/javascript" src="../resources/libraries/jquery.qtip-1.0.min.js"> 
</script> 

            </div>
        </div>
</div> 
</div> 
</div>
<?php include("php/footer.php");?>