<?php

// get posted data into local variables
$EmailFrom = "info@brooksidewalkandtrain.com";
$EmailTo = "info@brooksidewalkandtrain.com";
$Subject = "Message from a Customer";
$FirstName = Trim(stripslashes($_POST['FirstName'])); 
$LastName = Trim(stripslashes($_POST['LastName'])); 
$streetaddress = Trim(stripslashes($_POST['streetaddress'])); 
$City = Trim(stripslashes($_POST['City'])); 
$State = Trim(stripslashes($_POST['State'])); 
$zip = Trim(stripslashes($_POST['zip'])); 
$email = Trim(stripslashes($_POST['email'])); 
$phone = Trim(stripslashes($_POST['phone'])); 
$dogname = Trim(stripslashes($_POST['dogname'])); 
$male = Trim(stripslashes($_POST['male'])); 
$female = Trim(stripslashes($_POST['female'])); 
$yes = Trim(stripslashes($_POST['yes'])); 
$no = Trim(stripslashes($_POST['no'])); 
$microchipnumber = Trim(stripslashes($_POST['microchip number'])); 
$contactname = Trim(stripslashes($_POST['contact name'])); 
$phonenumber = Trim(stripslashes($_POST['phone number'])); 
$cellphonenumber = Trim(stripslashes($_POST['cellphonenumber'])); 
$emergency_cell_phone= Trim(stripslashes($_POST['vet information'])); 

// validation
$validationOK=true;
if (Trim($FirstName)=="") $validationOK=false;
if (!$validationOK) {
  print "<meta http-equiv=\"refresh\" content=\"0;URL=HtmlContact.php\">";
  exit;
}
$validationOK=true;
if (Trim($LastName)=="") $validationOK=false;
if (!$validationOK) {
 print "<meta http-equiv=\"refresh\" content=\"0;URL=HtmlContact.php\">";
  exit;
}
$validationOK=true;
if (Trim($City)=="") $validationOK=false;
if (!$validationOK) {
  print "<meta http-equiv=\"refresh\" content=\"0;URL=HtmlContact.php\">";
  exit;
}
$validationOK=true;
if (Trim($phone)=="") $validationOK=false;
if (!$validationOK) {
 print "<meta http-equiv=\"refresh\" content=\"0;URL=HtmlContact.php\">";
  exit;
}
$validationOK=true;
if (Trim($email)=="") $validationOK=false;
if (!$validationOK) {
  print "<meta http-equiv=\"refresh\" content=\"0;URL=HtmlContact.php\">";
  exit;
}
$validationOK=true;
if (Trim($dogname)=="") $validationOK=false;
if (!$validationOK) {
  print "<meta http-equiv=\"refresh\" content=\"0;URL=HtmlContact.php\">";
  exit;
}





// prepare email body text
$Body = "";
$Body .= "FirstName: ";
$Body .= $FirstName;
$Body .= "\n";
$Body .= "LastName: ";
$Body .= $LastName;
$Body .= "\n";
$Body .= "streetaddress: ";
$Body .= $streetaddress;
$Body .= "\n";
$Body .= "City: ";
$Body .= $City;
$Body .= "\n";
$Body .= "State: ";
$Body .= $State;
$Body .= "\n";
$Body .= "zip: ";
$Body .= $zip;
$Body .= "\n";
$Body .= "email: ";
$Body .= $email;
$Body .= "\n";
$Body .= "phone: ";
$Body .= $phone;
$Body .= "\n";
$Body .= "dogname: ";
$Body .= $dogname;
$Body .= "\n";
$Body .= "male: ";
$Body .= $male;
$Body .= "\n";
$Body .= "female: ";
$Body .= $female;
$Body .= "\n";
$Body .= "yes: ";
$Body .= $yes;
$Body .= "\n";
$Body .= "no: ";
$Body .= $no;
$Body .= "\n";
$Body .= "microchipnumber: ";
$Body .= $microchipnumber;
$Body .= "\n";
$Body .= "contactname: ";
$Body .= $contactname;
$Body .= "\n";
$Body .= "phonenumber: ";
$Body .= $phonenumber;
$Body .= "\n";
$Body .= "cellphonenumber: ";
$Body .= $cellphonenumber;
$Body .= "\n";
$Body .= "emergency_cell_phone: ";
$Body .= $emergency_cell_phone;
$Body .= "\n";



// send email 
$success = mail($EmailTo, $Subject, $Body, "From: <$EmailFrom>");

// redirect to success page 
if ($success){
  print "<meta http-equiv=\"refresh\" content=\"0;URL=success.php\">";
}
else{
  print "<meta http-equiv=\"refresh\" content=\"0;URL=HtmlContact.php\">";
}
?>
