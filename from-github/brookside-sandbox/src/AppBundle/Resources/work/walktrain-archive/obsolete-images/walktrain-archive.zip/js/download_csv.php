<?php
// File: download_csv.php
// Author: HTMLForm.com
// Purpose: Download form data in CSV format
// Modified: 29/10/2010


// Loading Gladius DB library
include '../resources/db/gladius.php';

// Reading form configuration file
$ini_array = parse_ini_file("form_config.ini",true);

// Setting Gladius DB connection
$G = new Gladius();
$G->SetDBRoot(dirname(__FILE__).'/db/');

// Setting Gladius DB database
$db_name = $ini_array['general']['db_name'];
$G->SelectDB($db_name) or die($G->errstr);

// Setting Gladius DB table 
$table_name = $ini_array['general']['table_name'];

// Query
$query = "select * from ".$table_name;
$rs = $G->Query($query);
$data = $rs->GetArray();

// Dumping data to an Array
$view = array();

$r = 0;

foreach ($data as $row) {
	$c = 0;
	$view[$r] = array();
	foreach($row as $label => $value) {
		$view[$r][$c] = $value;
		$c+=1;
	}
	$r+=1;
	}


// Checking user password for data
$password = "somepassword";
if (!(isset($ini_array['general']['password']) && $ini_array['general']['password']!="") || md5($_POST['txtPassword']) == $ini_array['general']['password']  ) {

// Exporting Array to CSV format
outputCSV($data,$ini_array );

} else { ?>


<h1>Login</h1>


<form name="form" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">

    
    <p><label for="txtpassword">Password:</label>

    <br /><input type="password" title="Enter your password" name="txtPassword" /></p>

    <p><input type="submit" name="Submit" value="Login" /></p>

</form>

<?php } 


// Function that exports data Array to CSV format
function outputCSV($data, $ini_array) {


    // deliver header (as recommended in php manual)
    header("Content-Type: text/csv; charset=unicode");
    header("Content-Disposition: inline; filename=\"" . $ini_array['general']['db_name']."_data.csv" . "\"");

    // print out document to the browser
    // need to use stripslashes for the damn ">"
    
    $r=0;
	foreach ($data as $row) {
		$line="";
		$fields="";
		$c=0;
		foreach($row as $label => $value) {
			
			
			$fields.= ($c)?$ini_array['labels'][$label].";":"id;";
			$line.= utf8_decode($value).";";
			$c+=1;
		}
		
		if ($r==0) { echo $fields."\n"; }
		echo $line."\n";
		$r+=1;
	}
	
	

}


?>

