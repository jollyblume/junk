<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>policies</title>
<link rel="stylesheet"type="text/css" href="css/style.css" />
<link rel="shortcut icon" href="images/favicon.ico" />
<style>
#ThreeColumns{height:825px}
h3{border:none; margin-bottom:0px}
</style>

</head>

<body>
<div id="container"> 
	<div id="RepeatingFence"></div> 
    <div id="InsideHeader"></div>
    <div style="position:absolute; z-index:-1; width:1000px; height:335px; top:670px">
    <table id="Table_01" width="1000" height="335" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td><img src="images/PoliciesBack_01.png" width="200" height="67" alt=""></td>
		<td><img src="images/PoliciesBack_02.png" width="200" height="67" alt=""></td>
		<td><img src="images/PoliciesBack_03.png" width="200" height="67" alt=""></td>
		<td><img src="images/PoliciesBack_04.png" width="200" height="67" alt=""></td>
		<td><img src="images/PoliciesBack_05.png" width="200" height="67" alt=""></td>
	</tr><tr>
		<td><img src="images/PoliciesBack_06.png" width="200" height="67" alt=""></td>
		<td><img src="images/PoliciesBack_07.png" width="200" height="67" alt=""></td>
		<td><img src="images/PoliciesBack_08.png" width="200" height="67" alt=""></td>
		<td><img src="images/PoliciesBack_09.png" width="200" height="67" alt=""></td>
		<td><img src="images/PoliciesBack_10.png" width="200" height="67" alt=""></td>
	</tr><tr>
		<td><img src="images/PoliciesBack_11.png" width="200" height="67" alt=""></td>
		<td><img src="images/PoliciesBack_12.png" width="200" height="67" alt=""></td>
		<td><img src="images/PoliciesBack_13.png" width="200" height="67" alt=""></td>
		<td><img src="images/PoliciesBack_14.png" width="200" height="67" alt=""></td>
		<td><img src="images/PoliciesBack_15.png" width="200" height="67" alt=""></td>
	</tr><tr>
		<td><img src="images/PoliciesBack_16.png" width="200" height="67" alt=""></td>
		<td><img src="images/PoliciesBack_17.png" width="200" height="67" alt=""></td>
		<td><img src="images/PoliciesBack_18.png" width="200" height="67" alt=""></td>
		<td><img src="images/PoliciesBack_19.png" width="200" height="67" alt=""></td>
		<td><img src="images/PoliciesBack_20.png" width="200" height="67" alt=""></td>
	</tr><tr>
		<td><img src="images/PoliciesBack_21.png" width="200" height="67" alt=""></td>
		<td><img src="images/PoliciesBack_22.png" width="200" height="67" alt=""></td>
		<td><img src="images/PoliciesBack_23.png" width="200" height="67" alt=""></td>
		<td><img src="images/PoliciesBack_24.png" width="200" height="67" alt=""></td>
		<td><img src="images/PoliciesBack_25.png" width="200" height="67" alt=""></td>
	</tr></table>
    
    
    </div>
<?php include("php/header.php");?> 		
		
		<div id="ThreeColumns">
        	<div id="col1">
            <h1>policies</h1>
			<h3>Cancellation policy</h3>
<p>Cancellations with less then 24 hours notice will be subject to a $10 cancellation fee. Any time no notification is given and a walker shows up at your home, there will be a 100% cancellation fee. 
<br />
<br />
Note: 100% cancellation fee is the cancellation fee of $10.00 plus, the cost of the service scheduled that day. 
<h3>Late bookings: </h3>
<p>Bookings made less then 24 hours in advance cannot be guaranteed. If we are able to provide service with less then 24 hours notice, there will be a $5 late booking fee. </p>
<h3>Boarding policy: </h3>
<p>A 50% non-refundable reservation fee is due upon booking. The remaining balance is due when your pet sitter picks up your dog. 
**Please make sure your dog is current on flea and tick preventative.</p>
</p>
</div>

            
            
            <div id="col2">
            <h1 class="blank">&nbsp;</h1>
            <h3>Client Responsibilities</h3>
<p>All leashes, collars and pinch collars must be in good working condition. If your dog bites another dog or person, or is bitten by another dog, you must inform us immediately. If you do not, and your dog bites another dog or person, you become liable for damages. </p>

<p>For in-home boarding for clients during winter months, client is responsible for clearing snow. Prior arrangements must be made for all snow removal. If Brookside has to clear walks, then client agrees to pay fee for removal.<p> 

<p>Brookside Walk and Train reserves the right to end walks, field trips, or other services due to extreme weather.</p>


<h3>KeyPolicies</h3>
<p>Clients are responsible for providing two sets of keys. Please be sure that both sets of keys work properly. If a walker is unable to get into your home, a 100% cancellation fee will be applied for the service scheduled that day.</p>  
            </div>
            
          <div id="col3">
            <h1 class="blank">&nbsp;</h1>
            <h3>Holidays</h3>
<p>Brookside Walk and Train observes the following holidays. If you need walks on these holidays, please contact Brookside Walk and Train to schedule an appointment.</p> 

<p style="margin-left:20px">
New Year´s Day<br />
MLK Day<br />
President´s Day<br />
Patriots Day<br />
Memorial Day<br />
July 4th<br />
Labor Day<br />
Columbus Day<br />
Veterans Day<br />
Thanksgiving Day<br />
Day After Thanksgiving<br />
Christmas Day 
</p>
<p>**The following fees are applied on national holidays; Walks: $5.00, Fieldtrips: $5.00, Boarding: $10.00.</p>
            </div>
        </div>
</div> 
</div> 
</div>
<?php include("php/footer.php");?>