<?php
// File: form_processor.php
// Author: HTMLForm.com
// Purpose: Process data submited by the form
// Modified: 29/10/2010

// Loading Gladius DB library
include '../db/gladius.php';

// Reading form configuration file
$ini_array = parse_ini_file("form_config.ini",true);

// If email notification activated....?
if(isset($ini_array['general']['send_email']) && $ini_array['general']['send_email'] && isset($ini_array['general']['email_account']) && $ini_array['general']['email_account']) {


// Composing message and header
    $form_name ="";
    if (isset($ini_array['general']['form_name'])) {
	$form_name  = $ini_array['general']['form_name'];
	} else {
	$form_name  = $ini_array['general']['form_id'];
	}
    $form_name = "HTMLForm.com notification: ".$form_name;
    //*** HTML body of the email.
    $strMessage = "<html><head><title>".$form_name."</title></head><body>";
    $strMessage .= valuesAsHtml($ini_array,false,$form_name);
    $strMessage .= "</body></html>";

    //*** Mail headers.
    $strHeaders = "MIME-Version: 1.0\r\n";
    $strHeaders .= "Content-type: text/html; charset=utf-8\r\n";
    if(isset($ini_array['general']['from_account'])){
	$strHeaders .= "From: ".$ini_array['general']['from_account']." \r\n";
    } else {
	$strHeaders .= "From: ".$ini_array['general']['email_account']." \r\n";
    }
    $strHeaders .= "Reply-To: noreply@htmlform.com \r\n";


    // Sending mail    
    mail($ini_array['general']['email_account'], $form_name.": new entry submitted", $strMessage, $strHeaders);
	

}


// Writting data in database
insertValues($ini_array);

// Processing confirmation message or redirecting to URL
if(isset($ini_array['general']['confirmation_message']) && $ini_array['general']['confirmation_message']) {
   	
   	//*** Set the output to a friendly thank you note.
   	$strOutput = $ini_array['general']['confirmation_message'];
	} else {
		if(isset($ini_array['general']['redirect_url']) && $ini_array['general']['redirect_url']) {
			header("Location: ".$ini_array['general']['redirect_url']);
	}
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<title>HTML Form</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<link type="text/css" rel="stylesheet" href="../resources/css/validform.css" />
<script type="text/javascript" src="../resources/libraries/jquery.js"></script>
</head>
<body>

<?php echo '<span class="confirmation_message">'.$strOutput.'</span>' ?>

        <script type="text/javascript">
        function resizeParentIframe() {
        
            try{
            parent.document.getElementById('myiframe').style.height = document.body.clientHeight+50+'px';
	    parent.document.getElementById('myiframe').style.width = document.body.clientWidth+'px';
        	}
        	catch(error) {}
        
        }
            // Create the tooltips only on document load
            $(document).ready(function() 
            {
            
<?php if($_GET['disableresizing']!='1') { ?>
            resizeParentIframe();
<?php } ?>            
            });
        </script>
</body>
</html>


<?php 
// Function that format fields data as HTML code

function get_file_name($element) {

return(($_GET[$element.'_name'])?'/uploads/'.$element.'/'.ltrim($_GET[$element.'_name']):$_GET[$element]);
}

function valuesAsHtml($values, $hideEmpty = FALSE,$form_name) {
		$strOutput = "<p>".$form_name.".<br/> A new entry has been sent:</p><table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">";
		
		$strOutput .= "<br/><b>Fields:</b><br/><br/>";
		
		foreach ($values['labels'] as $element => $label) {	
			
			$strSet = "";
				$strValue = get_file_name($element);
					if (is_array($strValue)) {
							$strSet .= "<tr>";
							$strSet .= "<td valign=\"top\" colspan=\"2\"><b>".$label.":&nbsp;&nbsp;&nbsp;</b></td><td valign=\"top\" colspan=\"2\"></td>\n";
							$strSet .= "</tr>";							
						foreach ($strValue as $option) {
								
							$strSet .= "<tr>";
							$strSet .= "<td valign=\"top\" colspan=\"2\"><b>&nbsp;&nbsp;&nbsp;".$option.":&nbsp;&nbsp;&nbsp;</b></td><td valign=\"top\" colspan=\"2\">selected</td>\n";
							$strSet .= "</tr>";							
						}
					}
					else {
						if ((!empty($strValue) && $hideEmpty) || (!$hideEmpty && !is_null($strValue))) {
							$strSet .= "<tr>";
							$strSet .= "<td valign=\"top\" colspan=\"2\"><b>".$label.":&nbsp;&nbsp;&nbsp;</b></td><td valign=\"top\" colspan=\"2\">".nl2br($strValue)."</td>\n";
							$strSet .= "</tr>";
					}

			}

			$strOutput .= $strSet;
		}
		
		$strOutput .= "</table>";
		
		return $strOutput;		

}


// Function that save data to database
function insertValues($values) {


	$G = new Gladius();
	$G->SetDBRoot(dirname(__FILE__).'/db/');
	$db_name = $values['general']['db_name'];
	$table_name = $values['general']['table_name'];
	$insert_row = "insert into ".$table_name." ";
	$fields = "";
	$data = "";

	foreach ($values['labels'] as $element => $label) {	
			$strSet = "";
			$strValue = get_file_name($element);
		
			if (is_array($strValue)) {
					$strSet_text = "";
					$vlist=array();
					foreach ($strValue as $option) {
						$vlist[$option]=1;
					}
					$llist=array();
					$pair=array();
					$llist=explode(";",$label);
					foreach($llist as $l) {
						$pair=explode(":",$l);
						if(isset($vlist[$pair[1]])) {
							$strSet_text .= "1;";
						} else {
							$strSet_text .= "0;";
						}
					}
					$strSet_text = substr($strSet_text, 0, strlen($strSet_text)-1);
			
					if(1==0) {
					foreach ($strValue as $option) {
						$strSet_text .= (($strSet_text!="")?"\\":"").utf8_encode($option);
					}
					}
					$data .= (($data!="")?",":"")."'".$strSet_text."'";
					$fields .= (($fields!="")?",":"").$element;
			}
			else {
					if ($strValue!="") {
						$strSet_text = $strValue;
						$fields .= (($fields!="")?",":"").$element;
						$data .= (($data!="")?",":"")."'".utf8_encode($strSet_text)."'";
					}

			}
	}
	if($fields) {
	$fields ="(".$fields.",ip,datetime)";
	$data ="values(".$data.",'".getenv('REMOTE_ADDR')."','".date( "d/m/Y h:m:s", time() )."')";
	$insert_row .= $fields." ".$data;
	
	$rs = $G->Query('USE '.$db_name);  
	$rs = $G->Query($insert_row);  		
	}	
}		

?>