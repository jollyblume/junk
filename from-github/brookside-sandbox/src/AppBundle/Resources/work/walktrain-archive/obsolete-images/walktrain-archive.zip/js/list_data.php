<?php
// File: list_data.php
// Author: HTMLForm.com
// Purpose: List data registered by the form. Uses Flexigrid component.
// Modified: 29/10/2010


// Loading Gladius DB library
include '../resources/db/gladius.php';

// Reading form configuration file
$ini_array = parse_ini_file("form_config.ini",true);

// Setting Gladius DB connection
$G = new Gladius();
$G->SetDBRoot(dirname(__FILE__).'/db/');

// Setting Gladius DB database
$db_name = $ini_array['general']['db_name'];
$G->SelectDB($db_name) or die($G->errstr);

// Setting Gladius DB table 
$table_name = $ini_array['general']['table_name'];

// Query register count
$query = "SELECT COUNT(*) FROM ".$table_name;;
$rs = $G->Query($query);
$result = $rs->getArray();
$counter = $result[0][0];

// Query data
$query = "select * from ".$table_name." where id > ".($counter-100);
$rs = $G->Query($query);
$data = $rs->GetArray();
$view = array();

// Dumping data to an Array
$numrows = sizeof($data);
$datadesc = array();
$r = 1;
foreach ($data as $row) {
	$datadesc[$numrows-$r]=$row;
	$r+=1;
}

$r = 0;

// Formating as HTML table in two Arrays: headers and lines
foreach ($datadesc as $row) {
	$c = 0;
	$view[$r] = array();
	foreach($row as $label => $value) {
		$view[$r][$c] = $value;
		$c+=1;
	}
	$r+=1;
	}
	
	$lengths = array();
	$headers="";
	$lines = "";
    $r=1;
	foreach ($data as $row) {
		$line="";
		$headers="";
		$c=0;
		foreach($row as $label => $value) {
			

			$line.= "<td>".utf8_decode($value)."</td>";
			if (strlen(utf8_decode($value)) > $length[$c]) {
				$length[$c] = strlen(utf8_decode($value));
			}
			if ($r==$r) {
			$headers = $headers."<th width=\"".($length[$c]*10)."\">";
			$label = (($c)?$ini_array['labels'][$label]:"id");
			$headers = $headers.$label;
			$headers = $headers."</th>";
			if (strlen($label) > $length[$c]) {
				$length[$c] = strlen($label);
			}			
			}			
			$c+=1;
		}
		
		
		$lines .= "<tr>".$line."</tr>";
		$r+=1;
	}	
	$headers = "<tr>".$headers."</tr>"; 

// Function that exports data Array to CSV format
function outputCSV($data, $ini_array) {


    // deliver header (as recommended in php manual)
    header("Content-Type: text/csv; charset=unicode");
    header("Content-Disposition: inline; filename=\"" . $ini_array['general']['db_name']."_data.csv" . "\"");

    // print out document to the browser
    // need to use stripslashes for the damn ">"
    
    $r=0;
	foreach ($data as $row) {
		$line="";
		$fields="";
		$c=0;
		foreach($row as $label => $value) {
			
			
			$fields.= ($c)?$ini_array['labels'][$label].";":"id;";
			$line.= utf8_decode($value).";";
			$c+=1;
		}
		
		if ($r==0) { echo $fields."\n"; }
		echo $line;
		$r+=1;
	}
	

}

?>




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>HTML form: list your data</title>
<link rel="stylesheet" type="text/css" href="../resources/libraries/flexigrid/css/flexigrid/flexigrid.css">
<link rel="stylesheet" type="text/css" href="../resources/css/validform.css">
<script type="text/javascript" src="../resources/libraries/jquery.js"></script>
<script type="text/javascript" src="../resources/libraries/flexigrid/flexigrid.js"></script>
<style>

	body
		{
		font-family: Arial, Helvetica, sans-serif;
		font-size: 12px;
		}
		
	.flexigrid div.fbutton .add
		{
			background: url(css/images/add.png) no-repeat center left;
		}	

	.flexigrid div.fbutton .delete
		{
			background: url(css/images/close.png) no-repeat center left;
		}	

		
</style>
</head>

<body style="background:#ffffff;">



<?php

// Define your username and password

$password = "somepassword";
if (!(isset($ini_array['general']['password']) && $ini_array['general']['password']!="") || md5($_POST['txtPassword']) == $ini_array['general']['password']  ) {


?>

<center><iframe src="http://www.htmlform.com/frame_top.php?id=<?=$ini_array['general']['form_id'] ?>" width=1024 height=250 frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe></center>
<center>
	
	<table><tr><td>
<div class="vf__description" style="width: 1024px; margin-top: 20px;">
<span style="font-size: large;">
                                    <span style="font-family: arial,helvetica,sans-serif;">
  <h1>HTMLform.com Data Query Tool</h1><br/>
  <p><strong>Form ID:</strong> <?php echo $ini_array['general']['form_id']; ?></p>
  <p><strong>Form Name:</strong> <?php echo $ini_array['general']['form_name']; ?></p><br/>
  <p><strong>Number of records:</strong> <?php echo $numrows; ?></p><br/>

<p>Will be showed up to 100 records, to download the full data in CSV format click <a href="download_csv.php">here</a></p>                                      
                                    </span>
                                </span>	

</div>
	</td></tr></table><br/><br/>
</center>
<center><table class="flexme1">
	<thead>

    		
			<?php echo $headers; ?>
            
    </thead>

    <tbody>
 			<?php echo $lines; ?>
    </tbody>
</table><br/><br/><br/>
</center>

<script type="text/javascript">


			$('.flexme1').flexigrid			(
			{
			usepager: true,
			title: '<?php echo $ini_array['general']['form_name'] ?>',
			useRp: true,
			rp: 15,
			showTableToggleBtn: false,
			width: 1024,
			height: 500
			}
			);


	
</script>

<center><iframe src="http://www.htmlform.com/frame_bottom.php?id=<?=$ini_array['general']['form_id'] ?>" width=1024 height=250 frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe></center>

<?php } else { ?>

<h1>Login</h1>



<form name="form" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">

    
    <p><label for="txtpassword">Password:</label>

    <br /><input type="password" title="Enter your password" name="txtPassword" /></p>



    <p><input type="submit" name="Submit" value="Login" /></p>



</form>

<?php } ?>
</body>
</html>